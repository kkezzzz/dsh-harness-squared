# Changelog

## 1.0.0

First release. Replaces the earlier UI-only bundle.

### Host half

- **Propose** (`src/ppc/propose.ts`): candidates only from counted trace
  signals — tool errors, repeated identical calls, steps without file effects —
  plus one domain-scoped candidate so a lesson can be contained instead of
  generalized. Each candidate carries the number that produced it.
- **Probe** (`src/ppc/probe.ts`): one isolated child per candidate. The
  candidate's prompt sections are registered on the probe agent's own context;
  the child gets a throwaway `meta.cwd` by default; the handle is disposed and
  the sandbox removed in `finally`.
- **Compose** (`src/ppc/compose.ts`): behavioural comparison only. A trace that
  stops closing turns, or that multiplies tool errors, is rejected as `unsafe`
  before any improvement is weighed. Same-section conflicts keep the stronger
  evidence and record the loser.
- **Budget** (`src/ppc/budget.ts`): candidate, round and estimated-token
  ceilings, all checked before spending.
- **Distillation** (`src/distill/reflect.ts`): accepted candidates become
  `EXPERIENCE.md` entries carrying the before/after counts; a turn hook can also
  record clean, productive turns as lower-confidence observations.
- **Experience library** (`src/store/`): domain-partitioned Markdown files, an
  index rewritten atomically through a mutex, merge-on-duplicate by title, and a
  root outside the package so uninstalling the plugin keeps the knowledge.
- **Recall** (`src/recall/inject.ts`): a `system-prompt/assemble` waterfall
  append, fenced as labelled evidence, capped per task so a long turn does not
  pay for the same hint repeatedly.
- **Overlay** (`src/apply/overlay.ts`): the committed generation is registered on
  the root prompt as exact disposers, so replacement is atomic in the Cordis
  sense — old sections disappear before new ones appear.
- **Surfaces**: four tools (`harness2_status`, `harness2_recall`,
  `harness2_experience`, `harness2_optimize`) and one zero-token command
  (`/harness2 status|list|recall|optimize|forget`).
- **Status** (`src/status.ts`): `status.json` snapshot for the sidebar and for
  anyone debugging a run.

### Browser half

- Sidebar entry `Harness²` and a console panel: the loop, the five commands with
  one-click copy, and the on-disk locations. It shows no live readout because a
  third-party bundle cannot register a Remote namespace — the panel points at
  the files instead of faking a channel.

### Correctness work

- `Config` implements the Standard Schema contract Cordis actually calls
  (`Config['~standard'].validate`). A plain defaults object crashes the fiber
  before `apply` runs.
- Services outside `inject` are resolved through a guarded accessor: Cordis
  throws on direct property access, so `if (ctx.commands)` was itself the bug.
- Section names are compared with the bundle prefix stripped, so a committed
  overlay is not re-proposed on the next run.

### Tests

57 offline assertions across 13 sections, covering isolation, trace
completeness, regression rejection, cost routing, the Standard Schema contract,
the command grammar and the full end-to-end run through the plugin surface.
