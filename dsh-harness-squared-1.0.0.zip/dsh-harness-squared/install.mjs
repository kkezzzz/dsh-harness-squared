#!/usr/bin/env node
/**
 * install.mjs - install dsh-harness-squared into a DSH profile.
 *
 * It changes four things and nothing else:
 *   1. copies this package to <profile>/plugins/dsh-harness-squared
 *   2. adds "dsh-harness-squared": "link:./plugins/dsh-harness-squared"
 *      to <profile>/package.json dependencies
 *   3. appends "dsh-harness-squared" to <profile>/package.json dsh.profile.bundles,
 *      which is what makes the Host apply this package's cordis.patch.yml
 *   4. links <profile>/node_modules/dsh-harness-squared at the copied package,
 *      which is what `pnpm install` would have produced for that link dependency
 *
 * The experience library is NOT created here and NOT removed on uninstall: it
 * lives under ~/.dsh/harness-squared (or the configured root) and outlives the
 * plugin by design.
 *
 *   node install.mjs                                   # profile "desktop"
 *   node install.mjs --profile desktop --dsh-home ~/.dsh
 *   node install.mjs --uninstall                       # reverse the four steps
 *   node install.mjs --dry-run                         # print the plan only
 *
 * Restart DSH afterwards: the Host applies bundle layers at startup.
 */
import { readFileSync, writeFileSync, copyFileSync, cpSync, existsSync, mkdirSync, readdirSync, rmSync, symlinkSync, lstatSync } from 'node:fs'
import { join, dirname, resolve, sep } from 'node:path'
import { homedir } from 'node:os'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const PACKAGE_NAME = 'dsh-harness-squared'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  if (i === -1) return fallback
  const next = process.argv[i + 1]
  return next && !next.startsWith('--') ? next : true
}
const flag = (name) => process.argv.includes(`--${name}`)

const dshHome = resolve(String(arg('dsh-home', join(homedir(), '.dsh'))).replace(/^~/, homedir()))
const wantedProfile = String(arg('profile', 'desktop'))
const uninstall = flag('uninstall')
const dryRun = flag('dry-run')

const fail = (message) => {
  console.error(`[x] ${message}`)
  process.exit(1)
}
const step = (message) => console.log(`${dryRun ? '[dry]' : '[ok]'} ${message}`)

const profilesRoot = join(dshHome, 'profiles')
if (!existsSync(profilesRoot)) fail(`找不到 ${profilesRoot}：用 --dsh-home 指定 DSH 主目录`)

const available = readdirSync(profilesRoot, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name)
if (!available.includes(wantedProfile)) {
  fail(`profile "${wantedProfile}" 不存在。可用：${available.join(', ') || '(无)'}`)
}

const profileDir = join(profilesRoot, wantedProfile)
const packageJsonPath = join(profileDir, 'package.json')
const pluginsDir = join(profileDir, 'plugins')
const destDir = join(pluginsDir, PACKAGE_NAME)
const linkPath = join(profileDir, 'node_modules', PACKAGE_NAME)
const stamp = new Date().toISOString().replace(/[:.]/g, '-')

const backup = (path) => {
  const target = `${path}.bak-${stamp}`
  copyFileSync(path, target)
  return target
}

/** Never overwrite a directory that is not recognisably this package. */
function assertOurs(target, label) {
  const inside = resolve(target).startsWith(resolve(pluginsDir) + sep)
  const manifest = join(target, 'package.json')
  const named = existsSync(manifest) && JSON.parse(readFileSync(manifest, 'utf8')).name === PACKAGE_NAME
  if (!inside || !named) fail(`${label} ${target} 已存在且不像 ${PACKAGE_NAME}，拒绝覆盖`)
}

const COPY_FILTER = (src) => !/(^|[\\/])(node_modules|\.git)([\\/]|$)/.test(src) && !src.endsWith('.bak')

function copyPackage() {
  if (existsSync(destDir)) {
    assertOurs(destDir, '目标目录')
    if (!dryRun) {
      rmSync(destDir, { recursive: true, force: true })
      cpSync(HERE, destDir, { recursive: true, filter: COPY_FILTER })
    }
    step(`覆盖插件 → ${destDir}`)
    return
  }
  if (!dryRun) {
    mkdirSync(pluginsDir, { recursive: true })
    cpSync(HERE, destDir, { recursive: true, filter: COPY_FILTER })
  }
  step(`复制插件 → ${destDir}`)
}

function removePackage() {
  if (!existsSync(destDir)) {
    step(`跳过：${destDir} 不存在`)
    return
  }
  assertOurs(destDir, '目标目录')
  if (!dryRun) rmSync(destDir, { recursive: true, force: true })
  step(`已删除 ${destDir}（经验库不在其中，未受影响）`)
}

function isReparse(path) {
  try {
    return lstatSync(path).isSymbolicLink()
  } catch {
    return false
  }
}

function editManifest(insert) {
  const raw = JSON.parse(readFileSync(packageJsonPath, 'utf8'))
  raw.dependencies = raw.dependencies || {}
  raw.dsh = raw.dsh || {}
  raw.dsh.profile = raw.dsh.profile || {}
  const bundles = Array.isArray(raw.dsh.profile.bundles) ? raw.dsh.profile.bundles : (raw.dsh.profile.bundles = [])

  let changed = false
  if (insert) {
    if (raw.dependencies[PACKAGE_NAME] !== `link:./plugins/${PACKAGE_NAME}`) {
      raw.dependencies[PACKAGE_NAME] = `link:./plugins/${PACKAGE_NAME}`
      changed = true
    }
    if (!bundles.includes(PACKAGE_NAME)) {
      bundles.push(PACKAGE_NAME)
      changed = true
    }
  } else {
    if (Object.prototype.hasOwnProperty.call(raw.dependencies, PACKAGE_NAME)) {
      delete raw.dependencies[PACKAGE_NAME]
      changed = true
    }
    const at = bundles.indexOf(PACKAGE_NAME)
    if (at !== -1) {
      bundles.splice(at, 1)
      changed = true
    }
  }

  if (!changed) {
    step(`跳过：${packageJsonPath} 已是目标状态`)
    return
  }
  if (dryRun) {
    step(`${insert ? '加入' : '移除'} ${packageJsonPath} 的 link 依赖与 bundles 行`)
    return
  }
  const backupPath = backup(packageJsonPath)
  writeFileSync(packageJsonPath, `${JSON.stringify(raw, null, 2)}\n`, 'utf8')
  step(`${insert ? '加入' : '移除'} ${packageJsonPath} 的 link 依赖与 bundles 行（备份 ${backupPath.split(sep).pop()}）`)
}

function linkPackage() {
  if (uninstall) {
    if (!existsSync(linkPath) && !isReparse(linkPath)) {
      step(`跳过：${linkPath} 不存在`)
      return
    }
    if (!dryRun) rmSync(linkPath, { recursive: true, force: true })
    step(`已移除链接 ${linkPath}`)
    return
  }
  if (!dryRun) mkdirSync(join(profileDir, 'node_modules'), { recursive: true })
  if (isReparse(linkPath)) {
    if (!dryRun) rmSync(linkPath, { recursive: true, force: true })
  } else if (existsSync(linkPath)) {
    fail(`${linkPath} 是真实目录，不是链接；请先手工确认它是什么`)
  }
  if (!dryRun) symlinkSync(join('..', 'plugins', PACKAGE_NAME), linkPath, 'junction')
  step(`建立链接 node_modules/${PACKAGE_NAME} → plugins/${PACKAGE_NAME}`)
}

console.log(`== ${uninstall ? '卸载' : '安装'} ${PACKAGE_NAME} → profile "${wantedProfile}" ==`)
console.log(`   dsh home : ${dshHome}`)
console.log(`   profile  : ${profileDir}`)

if (uninstall) {
  editManifest(false)
  linkPackage()
  removePackage()
  console.log('\n完成。重启 DSH 后工具、命令与侧边栏条目一并消失；经验库保留在原处。')
  process.exit(0)
}

copyPackage()
editManifest(true)
linkPackage()

console.log(`
下一步
  1) 完全退出并重新启动 DSH（bundle 层在启动时合成）
  2) 新会话里执行 /harness2 status，应立即返回经验库与预算状态（零 token）
  3) 侧边栏底部会出现「Harness²」条目，点开是控制栏
  4) 真正跑一次优化：/harness2 optimize（会消耗模型调用，受 tokenBudget 约束）

配置
  行配置在 profile 的 package.json -> dsh.profile.bundles 引入的 cordis.patch.yml 里，
  也可以在 Settings -> Plugins 里关闭整行。

回滚
  node install.mjs --uninstall
`)
