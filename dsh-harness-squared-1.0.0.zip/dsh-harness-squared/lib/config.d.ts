/**
 * Configuration: every field has a working default, so an empty row is a valid
 * row. `Config` is exported as a plain object on purpose - this bundle must not
 * depend on `@deepseek-ai/schemastery` resolving from a profile's
 * `node_modules`, which a profile-installed bundle cannot guarantee. The loader
 * hands the raw object to `apply`, and {@link resolveConfig} is the single place
 * that validates and defaults it.
 */
import type { Domain } from './types.js';
/** The model route a stage should use. */
export interface ModelRoute {
    provider: string;
    model: string;
    reasoningEffort?: string;
}
export interface HarnessSquaredConfig {
    /** Master switch; `false` registers nothing. */
    enabled: boolean;
    /** Experience library root. `~` expands to the home directory. */
    root: string;
    /** Domains this deployment declares up front; discovered ones are added later. */
    domains: Domain[];
    recall: {
        enabled: boolean;
        /** Maximum entries injected for one task. */
        maxEntries: number;
        /** Minimum lexical overlap (0..1) for an entry to count as a match. */
        minScore: number;
        /** Prompt order of the injected block. */
        order: number;
        /** Static shell description section, kept small and always-on cheap. */
        describeShell: boolean;
    };
    ppc: {
        enabled: boolean;
        /** Hard ceiling on candidates per run. */
        maxCandidates: number;
        /** Hard ceiling on recursion rounds (one round = one probe wave). */
        maxRounds: number;
        /** Estimated-token ceiling for one run. */
        tokenBudget: number;
        /** Route used by probe agents. Cheap by design. */
        probeModel: ModelRoute;
        /** Route used by reflection and composition reasoning. */
        reflectModel: ModelRoute;
        /** Per-probe wall clock limit. */
        probeTimeoutMs: number;
        /** Refuse a candidate whose probe cannot beat the baseline by this margin. */
        minImprovement: number;
        /** Run probes in a throwaway cwd instead of the session's workspace. */
        isolateWorkspace: boolean;
    };
    distill: {
        /** Turn a successful run into an experience entry. */
        enabled: boolean;
        /** Also distil ordinary turns (no probe) into experience. */
        onTurnEnd: boolean;
    };
    evidence: {
        /** Character cap for any trace text placed into a prompt or an entry. */
        maxChars: number;
        /** Character cap for one injected recall block. */
        maxInjectChars: number;
    };
}
/** Defaults; also the value exported as `Config`. */
export declare const DEFAULT_CONFIG: HarnessSquaredConfig;
/**
 * Expand a leading `~` and normalise separators.
 *
 * @param input - a filesystem path, possibly home-relative.
 * @returns an absolute path.
 */
export declare function expandHome(input: string): string;
/**
 * Validate a raw loader config into a complete {@link HarnessSquaredConfig}.
 *
 * Unknown keys are ignored rather than rejected: a profile written for a newer
 * version must not fail to boot on an older one.
 *
 * @param raw - whatever the loader passed.
 * @returns the effective configuration.
 */
export declare function resolveConfig(raw: unknown): HarnessSquaredConfig;
/**
 * The loader-facing schema.
 *
 * Cordis validates a plugin's `Config` through Standard Schema
 * (`runtime.Config['~standard'].validate(raw)` -> `{ value } | { issues }`,
 * read out of `cordis/lib/index.js`). A plain defaults object would therefore
 * crash activation, and a schemastery dependency cannot be assumed to resolve
 * from a profile's `node_modules`. This implements the three-property contract
 * directly, so validation is both cheap and dependency-free.
 */
export declare const ConfigSchema: {
    '~standard': {
        version: 1;
        vendor: string;
        /**
         * Never reports issues: unknown keys are ignored and every field clamps to
         * its documented range, because a config mistake must not stop the row from
         * booting.
         *
         * @param value - raw loader config.
         * @returns the normalised configuration.
         */
        validate(value: unknown): {
            value: HarnessSquaredConfig;
        };
    };
};
