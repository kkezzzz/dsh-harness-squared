/**
 * The active overlay: the shell patch that survived composition.
 *
 * This is the outer half of the recursion. A probe validates a change on one
 * agent; composition accepts it; the overlay then registers it on the *root*
 * context so every new step of every agent runs the improved shell. Sections
 * are held as disposers, so replacing the overlay is exact - the previous
 * generation disappears before the next one appears, with no duplicate names
 * and no leaked registrations.
 */
import type { HarnessSquaredConfig } from '../config.js';
import type { DshContext } from '../dsh.js';
import type { ActiveOverlay } from '../types.js';
export declare class OverlayManager {
    private readonly ctx;
    private readonly config;
    private readonly logger;
    private disposers;
    private overlay;
    constructor(ctx: DshContext, config: HarnessSquaredConfig, logger: {
        warn(...args: unknown[]): void;
        info(...args: unknown[]): void;
    });
    /** Absolute path of the persisted overlay. */
    get path(): string;
    /** The current overlay, if one has been loaded or accepted. */
    get current(): ActiveOverlay | null;
    /**
     * Read `overlay.json` and register it. A missing or malformed file simply
     * leaves the shell unmodified - never an activation failure.
     */
    load(): Promise<void>;
    /**
     * Replace the overlay with a composed generation and register it.
     *
     * @param input - sections from composition plus the run that produced them.
     * @returns the stored overlay; an empty section list clears the overlay.
     */
    commit(input: {
        sections: Array<{
            name: string;
            order: number;
            text: string;
        }>;
        runId: string;
        notes: string[];
    }): Promise<ActiveOverlay | null>;
    /** Dispose the current generation and register the current overlay. */
    apply(): void;
    /** Remove every registered section. */
    dispose(): void;
}
