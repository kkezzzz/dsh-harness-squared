/**
 * Distillation: turn a validated change into a reusable experience.
 *
 * Only composition's accepted candidates become entries, and every entry keeps
 * the numbers that admitted it. That is what makes the library auditable: a
 * reader can disagree with an entry and see exactly which trace difference it
 * rests on, without replaying anything.
 *
 * A turn-level hook exists too, but it records *observations* rather than shell
 * edits, and only for turns that finished cleanly and produced files - a turn
 * that failed is evidence for a probe, not a lesson to inject into the next one.
 */
import type { HarnessSquaredConfig } from '../config.js';
import type { Candidate, ExperienceEntry, TraceDelta, TraceSummary } from '../types.js';
export interface DistillRunInput {
    runId: string;
    task: string;
    domain: string;
    baseline: TraceSummary;
    accepted: Array<{
        candidate: Candidate;
        delta: TraceDelta;
        summary: string;
    }>;
    config: HarnessSquaredConfig;
}
/**
 * Build one experience entry per accepted candidate.
 *
 * @param input - run identity, task, baseline and accepted candidates.
 * @returns entries ready for `library.upsert`.
 */
export declare function distillRun(input: DistillRunInput): ExperienceEntry[];
/** The counted before/after table used as evidence. */
export declare function evidenceText(baseline: TraceSummary, delta: TraceDelta, summary: string): string;
export interface DistillTurnInput {
    task: string;
    domain: string;
    trace: TraceSummary;
    config: HarnessSquaredConfig;
}
/**
 * Record a clean, productive turn as a situational observation.
 *
 * @param input - the turn's task, domain and analysed trace.
 * @returns an entry, or `undefined` when the turn taught nothing.
 */
export declare function distillTurn(input: DistillTurnInput): ExperienceEntry | undefined;
