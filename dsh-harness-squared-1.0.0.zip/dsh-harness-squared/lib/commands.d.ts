/**
 * Slash commands: the zero-token control surface.
 *
 * A command runs directly against the agent and creates no model message, so
 * `/harness2 status` costs nothing and is safe to type mid-task. That is why the
 * sidebar control bar talks to the plugin this way: the alternative would be a
 * Remote RPC namespace, and a third-party bundle cannot add one.
 */
import type { DshContext, Disposer } from './dsh.js';
import type { ExperienceLibrary } from './store/library.js';
import type { OverlayManager } from './apply/overlay.js';
import type { PpcEngine } from './ppc/engine.js';
import type { HarnessSquaredConfig } from './config.js';
export interface CommandDeps {
    config: HarnessSquaredConfig;
    library: ExperienceLibrary;
    overlay: OverlayManager;
    engine: PpcEngine;
    version: string;
    logger: {
        warn(...args: unknown[]): void;
    };
}
/**
 * Register the `harness2` command.
 *
 * @param ctx - host context with `commands`.
 * @param deps - library, engine and overlay.
 * @returns the disposer, or an empty list when commands are not composed.
 */
export declare function registerCommands(ctx: DshContext, deps: CommandDeps): Disposer[];
