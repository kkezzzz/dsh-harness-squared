/**
 * The Harness² domain model.
 *
 * Two ideas carry the whole plugin:
 *
 * 1. **Behaviour, not answers.** Nothing here has a notion of a "correct"
 *    trajectory. A candidate is better only when its trace differs from the
 *    baseline in ways the metrics in {@link BehaviorMetrics} can show, and the
 *    comparison is expressed as {@link TraceDelta} - a set of counted,
 *    observable differences - never as a score or a verdict about meaning.
 *
 * 2. **The shell is data.** The thing being optimized is the execution shell:
 *    prompt sections, tool guidance, model routing and budgets. {@link HarnessEdit}
 *    is the closed vocabulary a candidate may change, so a probe can never
 *    invent a capability the host did not offer it.
 */
/** A domain is a free-form capability bucket used to keep experience isolated. */
export type Domain = string;
/** Where an experience came from. */
export type ExperienceOrigin = 'ppc' | 'manual' | 'seed' | 'distill';
/** Whether an edit is meant to generalize or to stay inside one domain. */
export type CandidateKind = 'invariant' | 'domain';
/**
 * The closed set of shell edits a candidate may propose.
 *
 * `append-prompt-section` is the only one that changes model-facing text; the
 * others steer routing and budgets, which is what makes a candidate
 * reproducible and its effect traceable back to one variable.
 */
export type HarnessEdit = {
    op: 'append-prompt-section';
    /** Section name; `harness-squared:` is prepended so ownership stays obvious. */
    name: string;
    /** Sort order inside the assembled prompt. */
    order: number;
    /** The text to append. Rendered verbatim: interpolation is disabled. */
    text: string;
    /** `true` when the section must never be shown outside its domain. */
    scoped: boolean;
} | {
    op: 'set-probe-model';
    provider: string;
    model: string;
    reasoningEffort?: string;
} | {
    op: 'set-budget';
    maxCandidates?: number;
    maxRounds?: number;
    tokenBudget?: number;
};
/** Observable facts extracted from one append-only trace. */
export interface BehaviorMetrics {
    /** Committed assistant steps. */
    steps: number;
    /** Tool invocations requested by the assistant. */
    toolCalls: number;
    /** Tool results flagged as errors, or carrying an `error` payload. */
    toolErrors: number;
    /** Calls that repeat the same tool with identical arguments. */
    repeatedToolCalls: number;
    /** Distinct file paths the trace wrote, edited or deleted. */
    filesTouched: number;
    /** Total assistant-visible text characters. */
    assistantChars: number;
    /** Characters of tool output the model had to read. */
    toolOutputChars: number;
    /** Whether the trace ends inside an unclosed turn. */
    completed: boolean;
    /** Wall-clock span of the trace, in milliseconds. */
    durationMs: number;
    /** Raw event count, the cheapest proxy for log pressure. */
    events: number;
}
/** One trace reduced to what a comparison needs. */
export interface TraceSummary {
    sessionId: string;
    metrics: BehaviorMetrics;
    /** Ordered tool names, the shape of the search strategy. */
    toolSequence: string[];
    /** First few error descriptions, sanitized, for experience entries. */
    errorSamples: string[];
    /** sha1 over the normalised tool sequence; two equal digests behaved alike. */
    digest: string;
}
/** A candidate shell modification plus the observation that motivated it. */
export interface Candidate {
    id: string;
    kind: CandidateKind;
    domain: Domain;
    /** One sentence stating what behaviour should change. */
    hypothesis: string;
    /** The signal in the baseline trace this candidate answers. */
    signal: string;
    edits: HarnessEdit[];
}
/** Counted differences between a baseline and one candidate trace. */
export interface TraceDelta {
    toolErrors: number;
    repeatedToolCalls: number;
    steps: number;
    filesTouched: number;
    toolOutputChars: number;
    durationMs: number;
    completed: boolean;
    /** Metric names that got materially better. */
    improved: string[];
    /** Metric names that got materially worse. */
    regressed: string[];
    /** `better` | `worse` | `neutral` | `unsafe`. */
    verdict: DeltaVerdict;
}
export type DeltaVerdict = 'better' | 'worse' | 'neutral' | 'unsafe';
/** Why a candidate was rejected; kept verbatim in the run record. */
export interface Rejection {
    candidateId: string;
    reason: string;
}
/** The shell patch that survived composition, applied to every new step. */
export interface ActiveOverlay {
    /** Monotonic revision, bumped on every accepted change. */
    revision: number;
    /** When composition produced it (ISO 8601). */
    acceptedAt: string;
    /** The run that produced it. */
    runId: string;
    sections: Array<{
        name: string;
        order: number;
        text: string;
    }>;
    notes: string[];
}
/** One experience entry; the on-disk Markdown carries the same fields. */
export interface ExperienceEntry {
    id: string;
    domain: Domain;
    kind: CandidateKind;
    title: string;
    /** 情境 - when this applies. */
    situation: string;
    /** 变更内容 - what changed in the shell. */
    change: string;
    /** 证据摘要 - the counted behaviour difference, never a score. */
    evidence: string;
    /** 复用条件 - the retrieval triggers. */
    reuse: string[];
    /** 0..1, derived from how many traces agreed. */
    confidence: number;
    origin: ExperienceOrigin;
    createdAt: string;
    /** Free-form tags used by retrieval. */
    tags: string[];
}
/** One completed PPC run, persisted for auditability. */
export interface PpcRunRecord {
    id: string;
    startedAt: string;
    finishedAt: string;
    domain: Domain;
    task: string;
    baselineSessionId: string;
    /** Candidates that were proposed. */
    proposed: number;
    /** Candidates that actually ran a probe. */
    probed: number;
    accepted: string[];
    rejected: Rejection[];
    /** Tokens the run is estimated to have spent. */
    estimatedTokens: number;
    /** Why the run stopped: `ok` | `budget` | `unsafe` | `no-candidate` | `error`. */
    outcome: 'ok' | 'budget' | 'unsafe' | 'no-candidate' | 'error';
    note: string;
}
