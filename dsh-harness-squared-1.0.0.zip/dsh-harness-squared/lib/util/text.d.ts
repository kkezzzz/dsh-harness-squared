/**
 * Text primitives shared by retrieval, evidence and the trace analyzer.
 *
 * Retrieval has to work for Chinese and English task text without a model call
 * and without a tokenizer dependency, so it uses the cheapest thing that does:
 * CJK character bigrams plus lower-cased ASCII words, scored by weighted
 * overlap. It is deliberately lexical - a miss costs one un-injected hint,
 * never a wrong instruction.
 */
/**
 * Split text into retrieval tokens.
 *
 * @param text - any task or entry text.
 * @returns lower-cased ASCII words plus CJK bigrams, deduplicated.
 */
export declare function tokenize(text: string): string[];
/**
 * Weighted overlap between a query and a document.
 *
 * @param query - tokens of the incoming task.
 * @param document - tokens of the candidate entry.
 * @returns a 0..1 score; 0 when either side is empty.
 */
export declare function overlap(query: string[], document: string[]): number;
/**
 * A stable short digest of an ordered sequence.
 *
 * @param parts - the sequence, typically tool names.
 * @returns 16 hex characters.
 */
export declare function digestSequence(parts: string[]): string;
/** Collapse any whitespace run to one space. */
export declare function oneLine(text: string): string;
/**
 * Cut a string to a character budget on a word boundary when possible.
 *
 * @param text - source text.
 * @param max - maximum characters to keep.
 * @returns the truncated text with an ellipsis marker when it was cut.
 */
export declare function truncate(text: string, max: number): string;
/**
 * A filesystem-safe slug.
 *
 * @param text - free text.
 * @param fallback - used when nothing survives normalisation.
 */
export declare function slug(text: string, fallback?: string): string;
/** ISO 8601 with seconds precision, the format the library stores. */
export declare function nowIso(): string;
/** Whether a string contains CJK characters. */
export declare function hasCjk(text: string): boolean;
