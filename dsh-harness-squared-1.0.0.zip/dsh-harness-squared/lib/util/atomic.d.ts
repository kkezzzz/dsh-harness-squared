/**
 * Durable file primitives.
 *
 * The experience library is the plugin's only durable state, and two probes
 * finishing at once must not interleave an index rewrite. Writes therefore go
 * `tmp -> fsync -> rename` in the target directory, and index mutations are
 * funnelled through {@link Mutex}.
 */
/**
 * Replace a file atomically.
 *
 * The temporary file lives in the destination directory so the final `rename`
 * stays on one volume, which is what makes it atomic on Windows and POSIX
 * alike. `sync()` runs before the rename so a crash cannot leave a renamed but
 * empty file.
 *
 * @param path - absolute destination.
 * @param data - complete UTF-8 contents.
 */
export declare function writeFileAtomic(path: string, data: string): Promise<void>;
/** Remove a file, tolerating its absence. */
export declare function removeFile(path: string): Promise<void>;
/**
 * A promise-chain mutex.
 *
 * Within one plugin instance this is enough to serialise index rewrites; the
 * README states explicitly that two host processes sharing one root are not
 * supported, rather than pretending a lockfile covers it.
 */
export declare class Mutex {
    private tail;
    /**
     * Run `task` after every previously queued task has settled.
     *
     * @param task - the critical section.
     * @returns the task's own result.
     */
    run<T>(task: () => Promise<T>): Promise<T>;
}
