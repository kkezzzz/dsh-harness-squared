/**
 * Lazy service resolution.
 *
 * `inject` decides when the plugin *activates*; it must not decide whether the
 * plugin can *run*. `sessions`, `agents` and `commands` are resolved at call
 * time instead, so a composition that mounts this bundle before the session
 * store still boots, and a thinner composition (headless, TUI) degrades to the
 * tools it actually has rather than failing to mount at all.
 */
import type { DshContext } from '../dsh.js';
/**
 * Read a service without assuming it is ready.
 *
 * Cordis exposes a mounted service as a context property *and* through `get()`;
 * both can throw while a service is absent, so both are guarded.
 *
 * @param ctx - the host context.
 * @param name - service name, e.g. `sessions`.
 * @returns the service, or `undefined` when this composition has no such service.
 */
export declare function service<T>(ctx: DshContext, name: string): T | undefined;
