/**
 * Evidence-boundary handling.
 *
 * Everything this plugin learns from is, by construction, untrusted data: task
 * text, tool output, model output, and previously stored experience all come
 * from a run that may itself have been steered. The rule the plugin enforces is
 * therefore structural rather than advisory:
 *
 *   - trace text never reaches a prompt as prose; it is fenced inside a block
 *     whose header states what it is and what it is not;
 *   - lines that read like instructions addressed to an agent are rewritten
 *     before fencing, so an injected "ignore previous instructions" survives as
 *     visible text but stops being a plausible directive;
 *   - every block is length-capped, so one hostile trace cannot dominate a
 *     prompt budget;
 *   - credential-shaped spans are replaced outright, because a stored secret
 *     would be re-read by every later run and has no analytical value.
 *
 * A sanitizer is not a sandbox. The README says so plainly: the remaining
 * defence is that injected experience can only add prompt *text*, never a tool,
 * a permission or a routing change on its own.
 */
/**
 * Normalise untrusted text for storage or prompt use.
 *
 * @param text - raw text from a trace, a tool result or a stored entry.
 * @param maxChars - hard character cap applied after normalisation.
 * @returns single-spaced, directive-neutralised, truncated text.
 */
export declare function sanitize(text: string, maxChars: number): string;
/** One-line variant for titles and summaries. */
export declare function sanitizeInline(text: string, maxChars: number): string;
/**
 * Fence untrusted text as an explicitly-labelled data block.
 *
 * The header and footer are the only part a model can rely on: they say who
 * produced the block, how old it is, and that its contents carry no authority.
 *
 * @param label - provenance, e.g. `experience:EXP-0003` or `trace:probe-2`.
 * @param text - already-sanitised text.
 * @returns the fenced block, ready to append to a prompt.
 */
export declare function evidenceBlock(label: string, text: string): string;
/**
 * Does this text look like an attempt to steer the reader?
 *
 * Used only to raise the run record's `note`; it never changes execution.
 *
 * @param text - untrusted text.
 * @returns the number of directive-looking lines found.
 */
export declare function countDirectives(text: string): number;
