/**
 * Model-facing tools.
 *
 * Four tools, deliberately few: status, recall, optimize, experience. They are
 * the only way a session can read or steer the library, and each returns plain
 * data that renders to text, so no part of this depends on a richer UI channel.
 *
 * The definitions are written as literal objects rather than through the
 * first-party `defineTool` helper: a profile-installed bundle cannot import
 * `@deepseek-ai/dsh-tools`, and `tools.register()` accepts a plain definition
 * whose `parameters` is already JSON Schema.
 */
import type { HarnessSquaredConfig } from './config.js';
import type { DshContext, Disposer } from './dsh.js';
import type { ExperienceLibrary } from './store/library.js';
import type { OverlayManager } from './apply/overlay.js';
import type { PpcEngine } from './ppc/engine.js';
export interface ToolDeps {
    config: HarnessSquaredConfig;
    library: ExperienceLibrary;
    overlay: OverlayManager;
    engine: PpcEngine;
    version: string;
    logger: {
        warn(...args: unknown[]): void;
    };
}
/**
 * Register every tool.
 *
 * @param ctx - host context with `tools`.
 * @param deps - library, engine, overlay and config.
 * @returns disposers for the registrations that succeeded.
 */
export declare function registerTools(ctx: DshContext, deps: ToolDeps): Disposer[];
