/**
 * Recall: inject matched experience into the system prompt.
 *
 * The injection point is the `system-prompt/assemble` waterfall, which the agent
 * loop dispatches once per proposed step with the assembly already built and the
 * step's `context` attached. The handler calls `next()` first, then appends one
 * section - so it composes with every other contributor instead of replacing
 * them, and a listener that throws only loses this section.
 *
 * Three cost controls keep a long turn from paying for the same hint ten times:
 * a lexical floor, a character cap, and a per-task step budget that resets when
 * the task text changes.
 */
import type { HarnessSquaredConfig } from '../config.js';
import type { DshContext, Disposer } from '../dsh.js';
import type { ExperienceLibrary, ScoredExperience } from '../store/library.js';
export interface RecallDeps {
    library: ExperienceLibrary;
    config: HarnessSquaredConfig;
    logger: {
        warn(...args: unknown[]): void;
        debug(...args: unknown[]): void;
    };
}
/** Name of the injected section. Also used to detect our own section. */
export declare const RECALL_SECTION = "harness-squared:recall";
/** Name of the static shell-description section. */
export declare const SHELL_SECTION = "harness-squared:shell";
/**
 * Register the static section and the dynamic recall waterfall.
 *
 * @param ctx - host context carrying `systemPrompt` and the event bus.
 * @param deps - library, config and logger.
 * @returns disposers, already owned by `ctx.effect` where applicable.
 */
export declare function registerRecall(ctx: DshContext, deps: RecallDeps): Disposer[];
/**
 * Recover the current task text from the assembly context.
 *
 * The loop passes `{ agent, scope, signal, modelSelection, toolSet }`, so the
 * session log is reachable without a second subscription. The last user message
 * is the task; anything else would have to guess.
 */
export declare function taskFromContext(context: any): string | undefined;
/**
 * Render the matched entries as one fenced evidence block.
 *
 * @param matches - scored entries, best first.
 * @param config - supplies the character cap.
 * @returns the block, or an empty string when the cap leaves nothing useful.
 */
export declare function buildRecallBlock(matches: ScoredExperience[], config: HarnessSquaredConfig): string;
/** Export for tests: the lexical part of the domain decision. */
export declare function scoreDomain(task: string, domain: string): number;
