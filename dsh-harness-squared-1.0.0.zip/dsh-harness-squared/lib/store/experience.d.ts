/**
 * Experience entries as Markdown.
 *
 * Markdown is the storage format for one reason: an experience is a claim about
 * how to behave, and a human has to be able to read, diff, edit or delete it
 * without tooling. The four required sections are exactly the four questions a
 * reader (or a model) needs answered:
 *
 *   情境     - when does this apply?
 *   变更内容  - what changed in the shell?
 *   证据摘要  - what observable difference justified it?
 *   复用条件  - what should trigger retrieval next time?
 */
import type { ExperienceEntry } from '../types.js';
/**
 * Serialise one entry.
 *
 * @param entry - the validated entry.
 * @returns a complete Markdown document.
 */
export declare function serializeExperience(entry: ExperienceEntry): string;
/**
 * Parse one stored document.
 *
 * Unparseable documents are returned as `undefined` rather than throwing: a
 * half-written file from an older version must not stop the library from
 * loading, it must only drop that entry.
 *
 * @param text - the file contents.
 * @param fallbackId - id from the file name, used when the front matter omits it.
 * @returns the entry, or `undefined` when required sections are missing.
 */
export declare function parseExperience(text: string, fallbackId: string): ExperienceEntry | undefined;
/** The relative path an entry lives at inside the library root. */
export declare function experiencePath(domain: string, id: string): string;
/**
 * Render the human-facing index.
 *
 * The index is regenerated whole on every change: it is a projection, never a
 * source of truth, and a whole-file atomic replace is simpler to reason about
 * than an in-place edit.
 *
 * @param entries - every entry, in stable id order.
 * @returns the INDEX.md contents.
 */
export declare function renderIndex(entries: ExperienceEntry[]): string;
