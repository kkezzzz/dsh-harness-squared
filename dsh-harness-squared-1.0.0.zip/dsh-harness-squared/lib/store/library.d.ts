/**
 * The experience library: a domain-partitioned, file-backed store.
 *
 * Design constraints that shaped it:
 *
 * - **Uninstall independence.** The root is a plain directory outside the
 *   plugin package, so removing the bundle leaves every entry behind. The
 *   self-test in `DEVELOPMENT.md` runs exactly that sequence.
 * - **Domain isolation.** Entries live under `domains/<domain>/` and retrieval
 *   scores the requested domain first, so a refactoring lesson from frontend
 *   work cannot silently leak into database migrations.
 * - **Bounded growth.** `upsert` merges by (domain, title-hash) and raises
 *   confidence instead of appending a near-duplicate, and `prune` drops the
 *   weakest entries once the cap is reached.
 */
import type { ExperienceEntry } from '../types.js';
/** Retrieval options. */
export interface SearchOptions {
    /** Domain to bias towards; entries from other domains stay eligible but rank lower. */
    domain?: string;
    /** Maximum entries returned. */
    limit?: number;
    /** Minimum score, 0..1. */
    minScore?: number;
}
/** Aggregate facts used by `harness2_status` and the sidebar. */
export interface LibraryStats {
    root: string;
    entries: number;
    domains: string[];
    byKind: {
        invariant: number;
        domain: number;
    };
    newest?: {
        id: string;
        title: string;
        createdAt: string;
    };
}
/** A stored entry with its retrieval score. */
export interface ScoredExperience {
    entry: ExperienceEntry;
    score: number;
}
export declare class ExperienceLibrary {
    readonly root: string;
    private readonly mutex;
    private entries;
    private loaded;
    constructor(root: string);
    /** Absolute path of INDEX.md. */
    get indexPath(): string;
    /**
     * Create the layout and load every entry.
     *
     * A missing root is created rather than treated as an error: the first run of
     * a fresh install must not need a manual `mkdir`.
     */
    open(): Promise<void>;
    /** Re-read every entry from disk, discarding in-memory state. */
    reload(): Promise<void>;
    /** Every entry, id order. */
    list(): ExperienceEntry[];
    /** One entry by id. */
    get(id: string): ExperienceEntry | undefined;
    /** Domain directories that currently exist on disk. */
    domainDirectories(): Promise<string[]>;
    /**
     * Rank entries against a task.
     *
     * @param task - the incoming task text.
     * @param options - domain bias, limit and floor.
     * @returns scored entries, best first; empty when nothing clears the floor.
     */
    search(task: string, options?: SearchOptions): ScoredExperience[];
    /**
     * Insert or merge one entry, then rewrite the index atomically.
     *
     * Merging is by (domain, title): a repeated lesson raises confidence and
     * refreshes the evidence instead of filling the library with duplicates.
     *
     * @param draft - the entry to store; `id` may be empty for a new one.
     * @returns the stored entry.
     */
    upsert(draft: ExperienceEntry): Promise<ExperienceEntry>;
    /**
     * Delete one entry and its index row.
     *
     * @param id - the entry id.
     * @returns whether an entry was removed.
     */
    remove(id: string): Promise<boolean>;
    /**
     * Drop the weakest entries down to `keep`.
     *
     * @param keep - entries to retain.
     * @returns ids that were removed.
     */
    prune(keep: number): Promise<string[]>;
    /** Aggregate facts for status output. */
    stats(): LibraryStats;
    /** Whether the library finished loading at least once. */
    get ready(): boolean;
    /** `EXP-0007` style identifier, one past the highest existing suffix. */
    private nextId;
    /** Rewrite INDEX.md from memory. Must run inside {@link mutex}. */
    private rewriteIndex;
}
/** Pick the best-matching declared domain for a task, or `general`. */
export declare function inferDomain(task: string, declared: string[]): string;
