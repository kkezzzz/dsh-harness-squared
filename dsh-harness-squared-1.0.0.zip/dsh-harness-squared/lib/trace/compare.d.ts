/**
 * Behavioural comparison - the only evaluation this plugin has.
 *
 * There is no rubric, no expected trajectory and no reference answer anywhere
 * in this file. A candidate wins by producing a trace that is *observably*
 * cheaper or cleaner than the baseline it was derived from, and loses when it
 * is observably worse. Two properties follow from that choice and both are
 * deliberate:
 *
 * - the comparison is symmetric and total, so the same function scores a
 *   candidate against a baseline and a rejected candidate against an accepted
 *   one during conflict reconciliation;
 * - safety is a hard gate, not a weight. A trace that stops completing turns,
 *   or that multiplies tool errors, is `unsafe` no matter how much else it
 *   improved - a harness edit that breaks execution must never be averaged in.
 */
import type { TraceDelta, TraceSummary } from '../types.js';
import type { DeltaVerdict } from '../types.js';
/**
 * Compare one candidate trace against the baseline.
 *
 * @param baseline - the unmodified shell's trace.
 * @param candidate - the trace produced under one candidate edit.
 * @returns counted differences and a verdict.
 */
export declare function compareTraces(baseline: TraceSummary, candidate: TraceSummary): TraceDelta;
/**
 * Whether a delta clears the configured improvement floor.
 *
 * @param delta - the comparison result.
 * @param minImprovement - how many metrics must have improved.
 */
export declare function meetsFloor(delta: TraceDelta, minImprovement: number): boolean;
/**
 * One-line justification, used both in the run record and in experience
 * evidence. It states counts only - never a judgement about correctness.
 *
 * @param delta - the comparison result.
 * @returns a compact sentence.
 */
export declare function describeDelta(delta: TraceDelta): string;
/**
 * Signed difference table for the run record; kept verbose on purpose so a
 * rejected candidate can be explained months later without replaying it.
 *
 * @param delta - the comparison result.
 */
export declare function deltaTable(delta: TraceDelta): Record<string, number | boolean>;
/** Verdict ordering used when two candidates conflict on the same edit key. */
export declare const VERDICT_RANK: Record<DeltaVerdict, number>;
