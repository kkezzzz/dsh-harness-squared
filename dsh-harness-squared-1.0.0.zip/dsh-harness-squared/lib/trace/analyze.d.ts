/**
 * Turn an append-only session log into comparable behaviour.
 *
 * The analyzer is the plugin's only source of truth about what an execution
 * shell *did*. It reads the log defensively - every field it touches may be
 * absent in another DSH version - and it never interprets intent. What comes
 * out is a fixed set of counts plus the ordered tool sequence, which is enough
 * to answer the only question composition is allowed to ask: did this trace
 * behave differently, and in which direction?
 */
import type { TraceSummary } from '../types.js';
import type { SessionEvent } from '../dsh.js';
/**
 * Project one session log into metrics plus a trace digest.
 *
 * @param sessionId - the session the events came from.
 * @param events - the complete log, oldest first.
 * @returns the summary used by probes, composition and experience entries.
 */
export declare function analyzeTrace(sessionId: string, events: SessionEvent[]): TraceSummary;
/**
 * Analyze the tail of a session starting at a sequence number.
 *
 * Probes record the log length they seeded with, so a forked child's inherited
 * prefix is not counted as work the candidate did.
 *
 * @param sessionId - the session id.
 * @param events - the complete log.
 * @param fromSeq - first sequence number to include.
 * @returns the summary of the selected window.
 */
export declare function analyzeFrom(sessionId: string, events: SessionEvent[], fromSeq: number): TraceSummary;
