/**
 * dsh-harness-squared - Harness² for DeepSeek Harness.
 *
 * What this bundle adds to a DSH installation, in one paragraph: an execution
 * shell that optimizes itself. Each run reads an append-only trace, proposes
 * shell edits from counted behavioural signals, probes every candidate in an
 * isolated child session, keeps only what measurably improved the trace, applies
 * the survivors to the root prompt, and stores the result as a domain-scoped
 * experience entry that later turns can recall.
 *
 * Nothing here scores an answer or compares against a reference trajectory. The
 * only evaluation is `trace/compare.ts`, and the only thing a change can touch is
 * the shell: prompt sections, model routing, budgets.
 *
 * Lifecycle: every registration is owned by a `ctx.effect`. Unloading the row
 * disposes the prompt sections, the tools, the command, the listeners and the
 * overlay in one pass, and leaves the experience library on disk untouched -
 * that independence is asserted by `test/run.mjs`.
 *
 * @module dsh-harness-squared
 */
import { DEFAULT_CONFIG } from './config.js';
import type { DshContext } from './dsh.js';
/**
 * Reported version. Kept as a literal so activation never depends on reading a
 * file; `test/run.mjs` asserts it matches package.json.
 */
export declare const VERSION = "1.0.0";
/** Loader-visible plugin name; matches the patch row id. */
export declare const name = "harness-squared";
/**
 * Exported schema.
 *
 * Cordis validates plugin config through Standard Schema
 * (`Config['~standard'].validate`), which is why this is a schema object rather
 * than the defaults map: a plain object crashes the fiber before `apply` runs.
 * {@link ConfigSchema} implements the contract directly, so no validation
 * library has to resolve from a profile's `node_modules`.
 */
export declare const Config: {
    '~standard': {
        version: 1;
        vendor: string;
        validate(value: unknown): {
            value: import("./config.js").HarnessSquaredConfig;
        };
    };
};
/**
 * The documented defaults, exported for tests and for the README's tables.
 * Not what the loader consumes - see {@link Config}.
 */
export { DEFAULT_CONFIG };
/**
 * Hard dependencies.
 *
 * Both are core to any agent composition, and both are needed *during* `apply`
 * (tools to register, systemPrompt to add sections). Everything else - sessions,
 * agents, commands - is resolved lazily so a thinner composition still boots.
 */
export declare const inject: string[];
/**
 * Mount the plugin.
 *
 * @param ctx - host context.
 * @param raw - loader configuration; anything missing falls back to defaults.
 */
export declare function apply(ctx: DshContext, raw?: unknown): Promise<void>;
