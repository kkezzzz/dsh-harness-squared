/**
 * Compose: decide what survives.
 *
 * Composition is the only place that can accept a change, and it accepts on
 * evidence alone:
 *
 *   1. a candidate with no trace is rejected (its probe never produced
 *      behaviour to compare);
 *   2. an `unsafe` verdict is rejected outright - a shell that stops finishing
 *      turns never gets averaged against one that finishes cheaply;
 *   3. a candidate must clear the configured improvement floor;
 *   4. two survivors that edit the same section are reconciled by keeping the
 *      one with more improved metrics, and the loser is recorded with a reason
 *      rather than dropped silently.
 *
 * Nothing here asks a model whether a change is good. The optional reflection
 * model in the config is used to *summarise* accepted evidence into prose for
 * the experience library; it cannot accept or reject.
 */
import type { Candidate, Rejection, TraceDelta, TraceSummary } from '../types.js';
import type { ProbeOutcome } from './probe.js';
export interface ComposedSection {
    name: string;
    order: number;
    text: string;
}
export interface AcceptedCandidate {
    candidate: Candidate;
    delta: TraceDelta;
    /** Human-readable summary of the counted difference. */
    summary: string;
}
export interface ComposeResult {
    accepted: AcceptedCandidate[];
    rejected: Rejection[];
    sections: ComposedSection[];
    notes: string[];
}
export interface ComposeInput {
    baseline: TraceSummary;
    proposals: Candidate[];
    outcomes: ProbeOutcome[];
    minImprovement: number;
}
/**
 * Reconcile every proposal against the evidence gathered for it.
 *
 * @param input - baseline, proposals and probe outcomes.
 * @returns the accepted set, the rejections with reasons, and the merged sections.
 */
export declare function compose(input: ComposeInput): ComposeResult;
