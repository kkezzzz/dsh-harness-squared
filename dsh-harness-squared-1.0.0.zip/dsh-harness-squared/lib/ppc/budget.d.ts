/**
 * Cost control for PPC runs.
 *
 * Every probe is a real agent execution, so an unbounded optimizer is an
 * unbounded bill. Three ceilings apply and all three are checked *before*
 * spending: candidate count, recursion rounds, and an estimated-token budget
 * derived from the traces the run has already read. When the budget is gone the
 * run stops and records why - it never silently returns a partial result that
 * looks complete.
 */
import type { SessionEvent } from '../dsh.js';
export interface BudgetLimits {
    maxCandidates: number;
    maxRounds: number;
    tokenBudget: number;
}
export interface BudgetSnapshot {
    used: number;
    limit: number;
    candidates: number;
    maxCandidates: number;
    rounds: number;
    maxRounds: number;
    exhausted: boolean;
}
/**
 * Estimate the token weight of a trace, counting only what a model would have
 * been asked to read: assistant text, tool output and call arguments.
 */
export declare function estimateTraceTokens(events: SessionEvent[]): number;
export declare class Budget {
    private readonly limits;
    private spent;
    private candidates;
    private rounds;
    private stopped;
    constructor(limits: BudgetLimits);
    /** Whether one more probe may run. Rounds gate {@link canRound}, not this. */
    canProbe(): boolean;
    /** Whether one more round may start. */
    canRound(): boolean;
    /** Charge an estimate before the spend happens. */
    charge(tokens: number): void;
    /** Record that one probe was admitted. */
    countProbe(): void;
    /** Record that one round was admitted. */
    countRound(): void;
    /** Freeze the budget, e.g. after an unsafe verdict. */
    stop(): void;
    /** Why the run stopped, for the run record. */
    get reason(): 'budget' | 'ok';
    snapshot(): BudgetSnapshot;
}
