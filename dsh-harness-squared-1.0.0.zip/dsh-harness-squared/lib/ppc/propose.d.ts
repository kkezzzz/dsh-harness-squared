/**
 * Propose: turn observed behaviour into candidate shell edits.
 *
 * Candidates are generated from *counted* observations in the baseline trace,
 * never from an opinion about what the model should have done. Each candidate
 * carries the signal that produced it, so a rejected candidate can still be
 * explained by pointing at the number it answered.
 *
 * Two kinds exist because they answer different risks:
 *
 * - `invariant` - the lesson should hold everywhere (do not repeat an identical
 *   call, verify before writing). It is proposed only when the trace shows the
 *   corresponding pathology.
 * - `domain` - the lesson is tied to a capability bucket (frontend, migration,
 *   data analysis). It exists so an invariant that only helps one domain can be
 *   scoped there instead of contaminating the rest, which is why it is ordered
 *   ahead of the lowest-value invariant when the candidate budget is tight.
 */
import type { Candidate, ExperienceEntry, TraceSummary } from '../types.js';
export interface ProposeInput {
    baseline: TraceSummary;
    task: string;
    domain: string;
    /** Hard cap from config. */
    maxCandidates: number;
    /** Section names already accepted, with or without the bundle prefix. */
    existingSections?: string[];
    /** Entries the library already holds for this domain. */
    known?: ExperienceEntry[];
}
/**
 * Build the candidate set for one baseline trace.
 *
 * @param input - baseline trace, task, domain and limits.
 * @returns candidates in priority order, never more than the cap.
 */
export declare function proposeCandidates(input: ProposeInput): Candidate[];
/**
 * Whether a candidate would change anything at all.
 *
 * @param candidate - the candidate under test.
 * @param existingSections - names already in force, prefixed or not.
 */
export declare function isNovel(candidate: Candidate, existingSections: string[]): boolean;
