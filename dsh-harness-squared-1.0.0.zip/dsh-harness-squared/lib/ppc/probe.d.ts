/**
 * Probe: run one candidate shell against the same task in an isolated child.
 *
 * Isolation is the whole point, so the mechanism is worth stating precisely:
 *
 * - **Prompt isolation.** A candidate's edits are registered on the *probe
 *   agent's* context (`setup(agentCtx)`), which Cordis scopes to that agent.
 *   The parent session, its prompt and every other agent never see them.
 * - **Filesystem isolation.** By default the probe gets a fresh session whose
 *   `meta.cwd` points at a throwaway directory under the run root, so any file
 *   the probe writes lands there and disappears with it. `fork` mode reuses the
 *   parent's cwd and therefore gives up that protection; the config documents
 *   the trade-off instead of pretending otherwise.
 * - **Teardown.** The handle is disposed, the sandbox directory removed, and the
 *   child session dropped even when the probe throws or times out.
 */
import type { HarnessSquaredConfig } from '../config.js';
import type { DshContext } from '../dsh.js';
import type { Candidate, TraceSummary } from '../types.js';
/** Services a probe needs; both are optional so a thin composition degrades. */
export interface ProbeHost {
    ctx: DshContext;
    config: HarnessSquaredConfig;
    /** Root for sandbox directories; usually `<root>/sandboxes`. */
    sandboxRoot: string;
}
export interface ProbeRequest {
    candidate: Candidate;
    /** The task text the baseline ran with, already sanitized by the caller. */
    task: string;
    /** Session the baseline came from; required for fork mode. */
    baselineSessionId: string;
    /** Baseline window length, used to skip inherited history in fork mode. */
    baselineEventCount: number;
}
export interface ProbeOutcome {
    candidateId: string;
    ok: boolean;
    /** Present when `ok` is false; a stable machine-readable reason. */
    reason?: string;
    detail?: string;
    trace?: TraceSummary;
    /** The route the probe agent was created with; asserted by cost-routing tests. */
    route: {
        provider: string;
        model: string;
    };
    /** Session id of the child, for the run record. */
    sessionId?: string;
    sandbox?: string;
}
/**
 * Execute one probe.
 *
 * @param host - services, config and sandbox root.
 * @param request - candidate, task and baseline identity.
 * @returns the outcome; never throws, so one bad candidate cannot end a run.
 */
export declare function runProbe(host: ProbeHost, request: ProbeRequest): Promise<ProbeOutcome>;
/**
 * Register a candidate's sections on the probe agent's own context.
 *
 * A missing `systemPrompt` service is tolerated: the probe still runs, it just
 * runs without the candidate, and composition will see a neutral delta.
 */
export declare function applyCandidate(agentCtx: DshContext, candidate: Candidate): void;
