/**
 * The PPC engine: Propose -> Probe -> Compose, then commit what survived.
 *
 * One run is a bounded, resumable-by-record operation:
 *
 *   baseline trace  ->  proposals  ->  N isolated probes  ->  composition
 *                   ->  overlay commit  ->  experience entries  ->  run record
 *
 * Every stage is allowed to produce nothing, and the run still ends with a
 * record explaining why. That matters more than a high acceptance rate: an
 * optimizer that cannot say "no change was justified" is not safe to leave on.
 *
 * Concurrency: one run per plugin instance. A second request returns the current
 * run's refusal instead of queueing, because two concurrent optimizations would
 * fight over the same overlay generation.
 */
import type { HarnessSquaredConfig } from '../config.js';
import type { DshContext, SessionEvent } from '../dsh.js';
import type { ExperienceLibrary } from '../store/library.js';
import type { OverlayManager } from '../apply/overlay.js';
import type { PpcRunRecord, TraceSummary } from '../types.js';
export interface EngineDeps {
    ctx: DshContext;
    config: HarnessSquaredConfig;
    library: ExperienceLibrary;
    overlay: OverlayManager;
    logger: {
        warn(...args: unknown[]): void;
        info(...args: unknown[]): void;
    };
    /** Called after a run settles, so the status snapshot can refresh. */
    onSettled?: (record: PpcRunRecord) => void | Promise<void>;
}
export interface RunInput {
    sessionId: string;
    /** Task text; defaults to the session's last user message. */
    task?: string;
    /** Domain override; defaults to lexical inference. */
    domain?: string;
}
export declare class PpcEngine {
    private readonly deps;
    private busy;
    private lastRun;
    constructor(deps: EngineDeps);
    /** Whether a run is in flight. */
    get running(): boolean;
    /** The most recent run in this process. */
    get last(): PpcRunRecord | null;
    /**
     * Run one Propose-Probe-Compose cycle.
     *
     * @param input - the session to learn from, plus optional task/domain.
     * @returns the run record, also written under `<root>/runs/`.
     */
    run(input: RunInput): Promise<PpcRunRecord>;
    /** Persist the record, notify the host and return it. */
    private settle;
    /** Fill the record's defaults. */
    private record;
}
/** The last user message in a log, used when no task was supplied. */
export declare function lastUserText(events: SessionEvent[]): string | undefined;
/** Re-export so tools can describe a failed baseline without importing the analyzer. */
export type { TraceSummary };
