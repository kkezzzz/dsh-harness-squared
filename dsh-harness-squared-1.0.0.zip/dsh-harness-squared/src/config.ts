/**
 * Configuration: every field has a working default, so an empty row is a valid
 * row. `Config` is exported as a plain object on purpose - this bundle must not
 * depend on `@deepseek-ai/schemastery` resolving from a profile's
 * `node_modules`, which a profile-installed bundle cannot guarantee. The loader
 * hands the raw object to `apply`, and {@link resolveConfig} is the single place
 * that validates and defaults it.
 */

import { homedir } from 'node:os'
import { join } from 'node:path'

import type { Domain } from './types.js'

/** The model route a stage should use. */
export interface ModelRoute {
  provider: string
  model: string
  reasoningEffort?: string
}

export interface HarnessSquaredConfig {
  /** Master switch; `false` registers nothing. */
  enabled: boolean
  /** Experience library root. `~` expands to the home directory. */
  root: string
  /** Domains this deployment declares up front; discovered ones are added later. */
  domains: Domain[]
  recall: {
    enabled: boolean
    /** Maximum entries injected for one task. */
    maxEntries: number
    /** Minimum lexical overlap (0..1) for an entry to count as a match. */
    minScore: number
    /** Prompt order of the injected block. */
    order: number
    /** Static shell description section, kept small and always-on cheap. */
    describeShell: boolean
  }
  ppc: {
    enabled: boolean
    /** Hard ceiling on candidates per run. */
    maxCandidates: number
    /** Hard ceiling on recursion rounds (one round = one probe wave). */
    maxRounds: number
    /** Estimated-token ceiling for one run. */
    tokenBudget: number
    /** Route used by probe agents. Cheap by design. */
    probeModel: ModelRoute
    /** Route used by reflection and composition reasoning. */
    reflectModel: ModelRoute
    /** Per-probe wall clock limit. */
    probeTimeoutMs: number
    /** Refuse a candidate whose probe cannot beat the baseline by this margin. */
    minImprovement: number
    /** Run probes in a throwaway cwd instead of the session's workspace. */
    isolateWorkspace: boolean
  }
  distill: {
    /** Turn a successful run into an experience entry. */
    enabled: boolean
    /** Also distil ordinary turns (no probe) into experience. */
    onTurnEnd: boolean
  }
  evidence: {
    /** Character cap for any trace text placed into a prompt or an entry. */
    maxChars: number
    /** Character cap for one injected recall block. */
    maxInjectChars: number
  }
}

/** Defaults; also the value exported as `Config`. */
export const DEFAULT_CONFIG: HarnessSquaredConfig = {
  enabled: true,
  root: join(homedir(), '.dsh', 'harness-squared'),
  domains: [],
  recall: {
    enabled: true,
    maxEntries: 3,
    minScore: 0.18,
    order: 11800,
    describeShell: true
  },
  ppc: {
    enabled: true,
    maxCandidates: 3,
    maxRounds: 1,
    tokenBudget: 120000,
    probeModel: { provider: 'deepseek-account', model: 'deepseek-flash' },
    reflectModel: { provider: 'deepseek-account', model: 'deepseek-pro', reasoningEffort: 'high' },
    probeTimeoutMs: 180000,
    minImprovement: 1,
    isolateWorkspace: true
  },
  distill: {
    enabled: true,
    onTurnEnd: false
  },
  evidence: {
    maxChars: 1200,
    maxInjectChars: 2400
  }
}

const isObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value)

const num = (value: unknown, fallback: number, min: number, max: number): number => {
  const parsed = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(parsed)) return fallback
  return Math.min(max, Math.max(min, parsed))
}

const bool = (value: unknown, fallback: boolean): boolean => (typeof value === 'boolean' ? value : fallback)

const str = (value: unknown, fallback: string): string =>
  typeof value === 'string' && value.trim().length > 0 ? value.trim() : fallback

const route = (value: unknown, fallback: ModelRoute): ModelRoute => {
  if (!isObject(value)) return { ...fallback }
  const merged: ModelRoute = {
    provider: str(value.provider, fallback.provider),
    model: str(value.model, fallback.model)
  }
  const effort = value.reasoningEffort
  if (typeof effort === 'string' && effort.length > 0) merged.reasoningEffort = effort
  else if (fallback.reasoningEffort) merged.reasoningEffort = fallback.reasoningEffort
  return merged
}

/**
 * Expand a leading `~` and normalise separators.
 *
 * @param input - a filesystem path, possibly home-relative.
 * @returns an absolute path.
 */
export function expandHome(input: string): string {
  if (input === '~') return homedir()
  if (input.startsWith('~/') || input.startsWith('~\\')) return join(homedir(), input.slice(2))
  return input
}

/**
 * Validate a raw loader config into a complete {@link HarnessSquaredConfig}.
 *
 * Unknown keys are ignored rather than rejected: a profile written for a newer
 * version must not fail to boot on an older one.
 *
 * @param raw - whatever the loader passed.
 * @returns the effective configuration.
 */
export function resolveConfig(raw: unknown): HarnessSquaredConfig {
  const d = DEFAULT_CONFIG
  if (!isObject(raw)) return cloneDefaults()

  const recall = isObject(raw.recall) ? raw.recall : {}
  const ppc = isObject(raw.ppc) ? raw.ppc : {}
  const distill = isObject(raw.distill) ? raw.distill : {}
  const evidence = isObject(raw.evidence) ? raw.evidence : {}

  const domains = Array.isArray(raw.domains)
    ? raw.domains.map((value) => str(value, '')).filter((value): value is string => value.length > 0)
    : []

  return {
    enabled: bool(raw.enabled, d.enabled),
    root: expandHome(str(raw.root, d.root)),
    domains,
    recall: {
      enabled: bool(recall.enabled, d.recall.enabled),
      maxEntries: num(recall.maxEntries, d.recall.maxEntries, 0, 12),
      minScore: num(recall.minScore, d.recall.minScore, 0, 1),
      order: num(recall.order, d.recall.order, -100000, 100000),
      describeShell: bool(recall.describeShell, d.recall.describeShell)
    },
    ppc: {
      enabled: bool(ppc.enabled, d.ppc.enabled),
      maxCandidates: num(ppc.maxCandidates, d.ppc.maxCandidates, 1, 8),
      maxRounds: num(ppc.maxRounds, d.ppc.maxRounds, 1, 3),
      tokenBudget: num(ppc.tokenBudget, d.ppc.tokenBudget, 1000, 5_000_000),
      probeModel: route(ppc.probeModel, d.ppc.probeModel),
      reflectModel: route(ppc.reflectModel, d.ppc.reflectModel),
      probeTimeoutMs: num(ppc.probeTimeoutMs, d.ppc.probeTimeoutMs, 5000, 1_800_000),
      minImprovement: num(ppc.minImprovement, d.ppc.minImprovement, 1, 20),
      isolateWorkspace: bool(ppc.isolateWorkspace, d.ppc.isolateWorkspace)
    },
    distill: {
      enabled: bool(distill.enabled, d.distill.enabled),
      onTurnEnd: bool(distill.onTurnEnd, d.distill.onTurnEnd)
    },
    evidence: {
      maxChars: num(evidence.maxChars, d.evidence.maxChars, 200, 20000),
      maxInjectChars: num(evidence.maxInjectChars, d.evidence.maxInjectChars, 400, 20000)
    }
  }
}

/** A deep copy so callers cannot mutate the exported defaults. */
function cloneDefaults(): HarnessSquaredConfig {
  const d = DEFAULT_CONFIG
  return {
    ...d,
    domains: [...d.domains],
    recall: { ...d.recall },
    ppc: { ...d.ppc, probeModel: { ...d.ppc.probeModel }, reflectModel: { ...d.ppc.reflectModel } },
    distill: { ...d.distill },
    evidence: { ...d.evidence }
  }
}

/**
 * The loader-facing schema.
 *
 * Cordis validates a plugin's `Config` through Standard Schema
 * (`runtime.Config['~standard'].validate(raw)` -> `{ value } | { issues }`,
 * read out of `cordis/lib/index.js`). A plain defaults object would therefore
 * crash activation, and a schemastery dependency cannot be assumed to resolve
 * from a profile's `node_modules`. This implements the three-property contract
 * directly, so validation is both cheap and dependency-free.
 */
export const ConfigSchema = {
  '~standard': {
    version: 1 as const,
    vendor: 'dsh-harness-squared',
    /**
     * Never reports issues: unknown keys are ignored and every field clamps to
     * its documented range, because a config mistake must not stop the row from
     * booting.
     *
     * @param value - raw loader config.
     * @returns the normalised configuration.
     */
    validate(value: unknown): { value: HarnessSquaredConfig } {
      return { value: resolveConfig(value) }
    }
  }
}
