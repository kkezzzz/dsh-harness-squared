/**
 * The experience library: a domain-partitioned, file-backed store.
 *
 * Design constraints that shaped it:
 *
 * - **Uninstall independence.** The root is a plain directory outside the
 *   plugin package, so removing the bundle leaves every entry behind. The
 *   self-test in `DEVELOPMENT.md` runs exactly that sequence.
 * - **Domain isolation.** Entries live under `domains/<domain>/` and retrieval
 *   scores the requested domain first, so a refactoring lesson from frontend
 *   work cannot silently leak into database migrations.
 * - **Bounded growth.** `upsert` merges by (domain, title-hash) and raises
 *   confidence instead of appending a near-duplicate, and `prune` drops the
 *   weakest entries once the cap is reached.
 */

import { existsSync } from 'node:fs'
import { mkdir, readFile, readdir } from 'node:fs/promises'
import { join } from 'node:path'

import { Mutex, removeFile, writeFileAtomic } from '../util/atomic.js'
import { overlap, slug, tokenize } from '../util/text.js'
import { experiencePath, parseExperience, renderIndex, serializeExperience } from './experience.js'
import type { ExperienceEntry } from '../types.js'

/** Retrieval options. */
export interface SearchOptions {
  /** Domain to bias towards; entries from other domains stay eligible but rank lower. */
  domain?: string
  /** Maximum entries returned. */
  limit?: number
  /** Minimum score, 0..1. */
  minScore?: number
}

/** Aggregate facts used by `harness2_status` and the sidebar. */
export interface LibraryStats {
  root: string
  entries: number
  domains: string[]
  byKind: { invariant: number; domain: number }
  newest?: { id: string; title: string; createdAt: string }
}

/** A stored entry with its retrieval score. */
export interface ScoredExperience {
  entry: ExperienceEntry
  score: number
}

export class ExperienceLibrary {
  readonly root: string
  private readonly mutex = new Mutex()
  private entries = new Map<string, ExperienceEntry>()
  private loaded = false

  constructor(root: string) {
    this.root = root
  }

  /** Absolute path of INDEX.md. */
  get indexPath(): string {
    return join(this.root, 'INDEX.md')
  }

  /**
   * Create the layout and load every entry.
   *
   * A missing root is created rather than treated as an error: the first run of
   * a fresh install must not need a manual `mkdir`.
   */
  async open(): Promise<void> {
    await mkdir(join(this.root, 'domains'), { recursive: true })
    await this.reload()
  }

  /** Re-read every entry from disk, discarding in-memory state. */
  async reload(): Promise<void> {
    const next = new Map<string, ExperienceEntry>()
    for (const domain of await this.domainDirectories()) {
      const dir = join(this.root, 'domains', domain)
      for (const file of await readdir(dir)) {
        if (!file.endsWith('.md')) continue
        const id = file.slice(0, -3)
        try {
          const entry = parseExperience(await readFile(join(dir, file), 'utf8'), id)
          if (entry) next.set(entry.id, entry)
        } catch {
          // A single unreadable file drops one entry, never the library.
        }
      }
    }
    this.entries = next
    this.loaded = true
    if (!existsSync(this.indexPath)) await this.rewriteIndex()
  }

  /** Every entry, id order. */
  list(): ExperienceEntry[] {
    return [...this.entries.values()].sort((a, b) => a.id.localeCompare(b.id))
  }

  /** One entry by id. */
  get(id: string): ExperienceEntry | undefined {
    return this.entries.get(id)
  }

  /** Domain directories that currently exist on disk. */
  async domainDirectories(): Promise<string[]> {
    const base = join(this.root, 'domains')
    if (!existsSync(base)) return []
    const names: string[] = []
    for (const file of await readdir(base)) {
      if (!file.includes('.')) names.push(file)
    }
    return names.sort()
  }

  /**
   * Rank entries against a task.
   *
   * @param task - the incoming task text.
   * @param options - domain bias, limit and floor.
   * @returns scored entries, best first; empty when nothing clears the floor.
   */
  search(task: string, options: SearchOptions = {}): ScoredExperience[] {
    const limit = options.limit ?? 3
    const minScore = options.minScore ?? 0.18
    if (task.trim().length === 0 || limit <= 0) return []
    const query = tokenize(task)
    if (query.length === 0) return []

    const scored: ScoredExperience[] = []
    for (const entry of this.entries.values()) {
      const document = tokenize(
        [entry.title, entry.situation, entry.change, entry.domain, ...entry.reuse, ...entry.tags].join(' ')
      )
      let score = overlap(query, document)
      if (score <= 0) continue
      if (options.domain && options.domain === entry.domain) score *= 1.35
      // Confidence is a tie-breaker, never a substitute for a lexical match.
      score *= 0.75 + entry.confidence * 0.25
      if (score >= minScore) scored.push({ entry, score })
    }

    return scored.sort((a, b) => b.score - a.score).slice(0, limit)
  }

  /**
   * Insert or merge one entry, then rewrite the index atomically.
   *
   * Merging is by (domain, title): a repeated lesson raises confidence and
   * refreshes the evidence instead of filling the library with duplicates.
   *
   * @param draft - the entry to store; `id` may be empty for a new one.
   * @returns the stored entry.
   */
  async upsert(draft: ExperienceEntry): Promise<ExperienceEntry> {
    return this.mutex.run(async () => {
      const existing = [...this.entries.values()].find(
        (entry) => entry.domain === draft.domain && entry.title === draft.title
      )
      const stored: ExperienceEntry = existing
        ? {
            ...draft,
            id: existing.id,
            createdAt: existing.createdAt,
            confidence: Math.min(1, Math.max(existing.confidence, draft.confidence) + 0.05)
          }
        : { ...draft, id: draft.id.length > 0 ? draft.id : this.nextId() }

      this.entries.set(stored.id, stored)
      await writeFileAtomic(join(this.root, experiencePath(stored.domain, stored.id)), serializeExperience(stored))
      await this.rewriteIndex()
      return stored
    })
  }

  /**
   * Delete one entry and its index row.
   *
   * @param id - the entry id.
   * @returns whether an entry was removed.
   */
  async remove(id: string): Promise<boolean> {
    return this.mutex.run(async () => {
      const entry = this.entries.get(id)
      if (!entry) return false
      this.entries.delete(id)
      await removeFile(join(this.root, experiencePath(entry.domain, entry.id)))
      await this.rewriteIndex()
      return true
    })
  }

  /**
   * Drop the weakest entries down to `keep`.
   *
   * @param keep - entries to retain.
   * @returns ids that were removed.
   */
  async prune(keep: number): Promise<string[]> {
    const ordered = [...this.entries.values()].sort((a, b) => b.confidence - a.confidence || a.createdAt.localeCompare(b.createdAt))
    const doomed = ordered.slice(Math.max(0, keep))
    for (const entry of doomed) await this.remove(entry.id)
    return doomed.map((entry) => entry.id)
  }

  /** Aggregate facts for status output. */
  stats(): LibraryStats {
    const all = this.list()
    const domains = [...new Set(all.map((entry) => entry.domain))].sort()
    const newest = [...all].sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0]
    return {
      root: this.root,
      entries: all.length,
      domains,
      byKind: {
        invariant: all.filter((entry) => entry.kind === 'invariant').length,
        domain: all.filter((entry) => entry.kind === 'domain').length
      },
      ...(newest ? { newest: { id: newest.id, title: newest.title, createdAt: newest.createdAt } } : {})
    }
  }

  /** Whether the library finished loading at least once. */
  get ready(): boolean {
    return this.loaded
  }

  /** `EXP-0007` style identifier, one past the highest existing suffix. */
  private nextId(): string {
    let highest = 0
    for (const id of this.entries.keys()) {
      const match = /^EXP-(\d+)$/.exec(id)
      if (match) highest = Math.max(highest, Number(match[1]))
    }
    return `EXP-${String(highest + 1).padStart(4, '0')}`
  }

  /** Rewrite INDEX.md from memory. Must run inside {@link mutex}. */
  private async rewriteIndex(): Promise<void> {
    await writeFileAtomic(this.indexPath, renderIndex(this.list()))
  }
}

/** Pick the best-matching declared domain for a task, or `general`. */
export function inferDomain(task: string, declared: string[]): string {
  if (declared.length === 0) return 'general'
  const query = tokenize(task)
  let best = 'general'
  let bestScore = 0
  for (const domain of declared) {
    const score = overlap(query, tokenize(domain))
    if (score > bestScore) {
      bestScore = score
      best = domain
    }
  }
  // A domain only wins on a real lexical hit, never on being the first entry.
  return bestScore >= 0.2 ? slug(best, 'general') : 'general'
}
