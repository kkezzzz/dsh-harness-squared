/**
 * Experience entries as Markdown.
 *
 * Markdown is the storage format for one reason: an experience is a claim about
 * how to behave, and a human has to be able to read, diff, edit or delete it
 * without tooling. The four required sections are exactly the four questions a
 * reader (or a model) needs answered:
 *
 *   情境     - when does this apply?
 *   变更内容  - what changed in the shell?
 *   证据摘要  - what observable difference justified it?
 *   复用条件  - what should trigger retrieval next time?
 */

import { nowIso, slug } from '../util/text.js'
import { sanitizeInline } from '../util/redact.js'
import type { CandidateKind, ExperienceEntry, ExperienceOrigin } from '../types.js'

/** Header delimiter used by the front matter. */
const FENCE = '---'

/**
 * Serialise one entry.
 *
 * @param entry - the validated entry.
 * @returns a complete Markdown document.
 */
export function serializeExperience(entry: ExperienceEntry): string {
  const front = [
    FENCE,
    `id: ${entry.id}`,
    `domain: ${entry.domain}`,
    `kind: ${entry.kind}`,
    `confidence: ${entry.confidence.toFixed(2)}`,
    `origin: ${entry.origin}`,
    `createdAt: ${entry.createdAt}`,
    `tags: [${entry.tags.map((tag) => slug(tag)).join(', ')}]`,
    FENCE
  ].join('\n')

  return [
    front,
    '',
    `# ${sanitizeInline(entry.title, 160)}`,
    '',
    '## 情境',
    '',
    entry.situation,
    '',
    '## 变更内容',
    '',
    entry.change,
    '',
    '## 证据摘要',
    '',
    entry.evidence,
    '',
    '## 复用条件',
    '',
    entry.reuse.length > 0 ? entry.reuse.map((item) => `- ${item}`).join('\n') : '- （无显式触发词，按领域匹配）',
    ''
  ].join('\n')
}

/**
 * Parse one stored document.
 *
 * Unparseable documents are returned as `undefined` rather than throwing: a
 * half-written file from an older version must not stop the library from
 * loading, it must only drop that entry.
 *
 * @param text - the file contents.
 * @param fallbackId - id from the file name, used when the front matter omits it.
 * @returns the entry, or `undefined` when required sections are missing.
 */
export function parseExperience(text: string, fallbackId: string): ExperienceEntry | undefined {
  const normalised = text.replace(/\r\n/g, '\n')
  const match = /^---\n([\s\S]*?)\n---\n/.exec(normalised)
  if (!match) return undefined
  const meta = new Map<string, string>()
  for (const line of match[1].split('\n')) {
    const pair = /^([A-Za-z][A-Za-z0-9_-]*):\s*(.*)$/.exec(line)
    if (pair) meta.set(pair[1], pair[2].trim())
  }
  const body = normalised.slice(match[0].length)

  const section = (heading: string): string => {
    const start = body.indexOf(`## ${heading}`)
    if (start === -1) return ''
    const after = body.slice(start + heading.length + 3)
    const next = after.search(/^## /m)
    return (next === -1 ? after : after.slice(0, next)).trim()
  }

  const situation = section('情境')
  const change = section('变更内容')
  const evidence = section('证据摘要')
  const reuseRaw = section('复用条件')
  if (situation.length === 0 || change.length === 0) return undefined

  const titleLine = body.split('\n').find((line) => line.startsWith('# '))
  const tagsRaw = meta.get('tags') ?? ''
  const confidenceRaw = Number(meta.get('confidence') ?? '0.5')

  return {
    id: meta.get('id') ?? fallbackId,
    domain: meta.get('domain') ?? 'general',
    kind: (meta.get('kind') as CandidateKind) ?? 'invariant',
    title: titleLine ? titleLine.slice(2).trim() : `${meta.get('domain') ?? 'general'} experience`,
    situation,
    change,
    evidence,
    reuse: reuseRaw
      .split('\n')
      .map((line) => line.replace(/^-\s*/, '').trim())
      .filter((line) => line.length > 0 && !line.startsWith('（')),
    confidence: Number.isFinite(confidenceRaw) ? Math.min(1, Math.max(0, confidenceRaw)) : 0.5,
    origin: (meta.get('origin') as ExperienceOrigin) ?? 'manual',
    createdAt: meta.get('createdAt') ?? nowIso(),
    tags:
      tagsRaw
        .replace(/^\[|\]$/g, '')
        .split(',')
        .map((tag) => tag.trim())
        .filter((tag) => tag.length > 0)
  }
}

/** The relative path an entry lives at inside the library root. */
export function experiencePath(domain: string, id: string): string {
  return `domains/${slug(domain, 'general')}/${id}.md`
}

/**
 * Render the human-facing index.
 *
 * The index is regenerated whole on every change: it is a projection, never a
 * source of truth, and a whole-file atomic replace is simpler to reason about
 * than an in-place edit.
 *
 * @param entries - every entry, in stable id order.
 * @returns the INDEX.md contents.
 */
export function renderIndex(entries: ExperienceEntry[]): string {
  const rows = [...entries]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map((entry) => {
      const link = `[${entry.id}](${experiencePath(entry.domain, entry.id)})`
      return `| ${link} | ${entry.domain} | ${entry.kind} | ${entry.confidence.toFixed(2)} | ${entry.createdAt} | ${sanitizeInline(entry.title, 80)} |`
    })

  return [
    '# Harness² experience index',
    '',
    '<!-- Generated by dsh-harness-squared. Edits are overwritten on the next write. -->',
    '',
    `Entries: ${entries.length}`,
    '',
    '| id | domain | kind | confidence | created | title |',
    '| --- | --- | --- | --- | --- | --- |',
    ...(rows.length > 0 ? rows : ['| — | — | — | — | — | (empty) |']),
    ''
  ].join('\n')
}
