/**
 * The status snapshot.
 *
 * The sidebar control bar has no RPC namespace it could call - a third-party
 * bundle cannot add one to the generated Typert surface - so the host publishes
 * its state as a small JSON document instead, and the panel reads that file.
 * The snapshot is deliberately flat, small and free of anything the host would
 * not want on disk: counts, ids, route names and the last run's verdict.
 */

import { join } from 'node:path'

import { writeFileAtomic } from './util/atomic.js'
import { nowIso } from './util/text.js'
import type { HarnessSquaredConfig } from './config.js'
import type { LibraryStats } from './store/library.js'
import type { ActiveOverlay, PpcRunRecord } from './types.js'

/** The document written to `<root>/status.json`. */
export interface RuntimeStatus {
  plugin: 'dsh-harness-squared'
  version: string
  enabled: boolean
  root: string
  updatedAt: string
  config: {
    recallEnabled: boolean
    ppcEnabled: boolean
    distillEnabled: boolean
    maxCandidates: number
    maxRounds: number
    tokenBudget: number
    probeModel: string
    reflectModel: string
  }
  library: LibraryStats
  overlay: { revision: number; acceptedAt: string; sections: number; runId: string } | null
  lastRun: PpcRunRecord | null
}

/**
 * Owns the snapshot file and serialises writes.
 *
 * Writes are coalesced: a run that commits three times in a second produces one
 * file write, because the panel only ever wants the latest state.
 */
export class StatusStore {
  private readonly root: string
  private readonly version: string
  private pending: Promise<void> = Promise.resolve()
  private dirty = false

  constructor(root: string, version: string) {
    this.root = root
    this.version = version
  }

  /** Absolute path of the snapshot. */
  get path(): string {
    return join(this.root, 'status.json')
  }

  /**
   * Build the snapshot document.
   *
   * @param input - live state gathered by the plugin.
   */
  build(input: {
    config: HarnessSquaredConfig
    library: LibraryStats
    overlay: ActiveOverlay | null
    lastRun: PpcRunRecord | null
  }): RuntimeStatus {
    const { config, library, overlay, lastRun } = input
    return {
      plugin: 'dsh-harness-squared',
      version: this.version,
      enabled: config.enabled,
      root: config.root,
      updatedAt: nowIso(),
      config: {
        recallEnabled: config.recall.enabled,
        ppcEnabled: config.ppc.enabled,
        distillEnabled: config.distill.enabled,
        maxCandidates: config.ppc.maxCandidates,
        maxRounds: config.ppc.maxRounds,
        tokenBudget: config.ppc.tokenBudget,
        probeModel: `${config.ppc.probeModel.provider}/${config.ppc.probeModel.model}`,
        reflectModel: `${config.ppc.reflectModel.provider}/${config.ppc.reflectModel.model}`
      },
      library,
      overlay: overlay
        ? { revision: overlay.revision, acceptedAt: overlay.acceptedAt, sections: overlay.sections.length, runId: overlay.runId }
        : null,
      lastRun
    }
  }

  /**
   * Persist a snapshot, coalescing overlapping calls.
   *
   * A failed write is swallowed: status is a convenience surface and must never
   * be the reason a run fails.
   *
   * @param status - the document to write.
   */
  async write(status: RuntimeStatus): Promise<void> {
    this.dirty = true
    this.pending = this.pending.then(async () => {
      if (!this.dirty) return
      this.dirty = false
      try {
        await writeFileAtomic(this.path, `${JSON.stringify(status, null, 2)}\n`)
      } catch {
        /* see above */
      }
    })
    await this.pending
  }
}
