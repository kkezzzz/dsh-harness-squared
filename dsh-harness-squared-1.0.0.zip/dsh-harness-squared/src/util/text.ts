/**
 * Text primitives shared by retrieval, evidence and the trace analyzer.
 *
 * Retrieval has to work for Chinese and English task text without a model call
 * and without a tokenizer dependency, so it uses the cheapest thing that does:
 * CJK character bigrams plus lower-cased ASCII words, scored by weighted
 * overlap. It is deliberately lexical - a miss costs one un-injected hint,
 * never a wrong instruction.
 */

import { createHash } from 'node:crypto'

/** Words that carry no retrieval signal in either language. */
const STOPWORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'if', 'then', 'than', 'that', 'this', 'these', 'those',
  'is', 'are', 'was', 'were', 'be', 'been', 'to', 'of', 'in', 'on', 'at', 'for', 'with', 'by',
  'as', 'it', 'its', 'from', 'into', 'so', 'we', 'you', 'i', 'me', 'my', 'our', 'your',
  'do', 'does', 'did', 'can', 'could', 'should', 'would', 'will', 'not', 'no', 'yes',
  '的', '了', '和', '是', '在', '我', '你', '他', '她', '它', '们', '这', '那', '有', '就',
  '也', '都', '而', '与', '及', '或', '被', '把', '给', '对', '从', '到', '一个', '一下'
])

const CJK = /[\u3400-\u9fff\uf900-\ufaff]/

/**
 * Split text into retrieval tokens.
 *
 * @param text - any task or entry text.
 * @returns lower-cased ASCII words plus CJK bigrams, deduplicated.
 */
export function tokenize(text: string): string[] {
  const normalised = text.toLowerCase()
  const tokens = new Set<string>()
  const words = normalised.match(/[a-z0-9_][a-z0-9_.#/-]{1,}/g) ?? []
  for (const word of words) {
    if (word.length < 2) continue
    if (STOPWORDS.has(word)) continue
    tokens.add(word)
  }
  for (const run of normalised.match(/[\u3400-\u9fff\uf900-\ufaff]+/g) ?? []) {
    if (run.length === 1) {
      tokens.add(run)
      continue
    }
    for (let index = 0; index + 2 <= run.length; index += 1) {
      const bigram = run.slice(index, index + 2)
      if (!STOPWORDS.has(bigram)) tokens.add(bigram)
    }
  }
  return [...tokens]
}

/**
 * Weighted overlap between a query and a document.
 *
 * @param query - tokens of the incoming task.
 * @param document - tokens of the candidate entry.
 * @returns a 0..1 score; 0 when either side is empty.
 */
export function overlap(query: string[], document: string[]): number {
  if (query.length === 0 || document.length === 0) return 0
  const querySet = new Set(query)
  const documentSet = new Set(document)
  let shared = 0
  for (const token of querySet) if (documentSet.has(token)) shared += 1
  if (shared === 0) return 0
  // Coverage of the query dominates precision of the document: a long entry
  // that covers half the task is more useful than a short one covering one word.
  return (shared / querySet.size) * 0.75 + (shared / documentSet.size) * 0.25
}

/**
 * A stable short digest of an ordered sequence.
 *
 * @param parts - the sequence, typically tool names.
 * @returns 16 hex characters.
 */
export function digestSequence(parts: string[]): string {
  const hash = createHash('sha1')
  hash.update(parts.join('\u0000'))
  return hash.digest('hex').slice(0, 16)
}

/** Collapse any whitespace run to one space. */
export function oneLine(text: string): string {
  return text.replace(/\s+/g, ' ').trim()
}

/**
 * Cut a string to a character budget on a word boundary when possible.
 *
 * @param text - source text.
 * @param max - maximum characters to keep.
 * @returns the truncated text with an ellipsis marker when it was cut.
 */
export function truncate(text: string, max: number): string {
  if (text.length <= max) return text
  const slice = text.slice(0, max)
  const boundary = slice.lastIndexOf(' ')
  const cut = boundary > max * 0.6 ? slice.slice(0, boundary) : slice
  return `${cut}…[truncated ${text.length - cut.length} chars]`
}

/**
 * A filesystem-safe slug.
 *
 * @param text - free text.
 * @param fallback - used when nothing survives normalisation.
 */
export function slug(text: string, fallback = 'entry'): string {
  const cleaned = text
    .toLowerCase()
    .replace(/[^a-z0-9\u3400-\u9fff]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48)
  return cleaned.length > 0 ? cleaned : fallback
}

/** ISO 8601 with seconds precision, the format the library stores. */
export function nowIso(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')
}

/** Whether a string contains CJK characters. */
export function hasCjk(text: string): boolean {
  return CJK.test(text)
}
