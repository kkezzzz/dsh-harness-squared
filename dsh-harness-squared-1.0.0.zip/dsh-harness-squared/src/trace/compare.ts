/**
 * Behavioural comparison - the only evaluation this plugin has.
 *
 * There is no rubric, no expected trajectory and no reference answer anywhere
 * in this file. A candidate wins by producing a trace that is *observably*
 * cheaper or cleaner than the baseline it was derived from, and loses when it
 * is observably worse. Two properties follow from that choice and both are
 * deliberate:
 *
 * - the comparison is symmetric and total, so the same function scores a
 *   candidate against a baseline and a rejected candidate against an accepted
 *   one during conflict reconciliation;
 * - safety is a hard gate, not a weight. A trace that stops completing turns,
 *   or that multiplies tool errors, is `unsafe` no matter how much else it
 *   improved - a harness edit that breaks execution must never be averaged in.
 */

import type { BehaviorMetrics, TraceDelta, TraceSummary } from '../types.js'
import type { DeltaVerdict } from '../types.js'

/** Relative drop in tool output that counts as a real context saving. */
const OUTPUT_SAVING_RATIO = 0.2

/** A candidate that loses more steps than this without any gain is worse. */
const STEP_REGRESSION = 2

/**
 * Compare one candidate trace against the baseline.
 *
 * @param baseline - the unmodified shell's trace.
 * @param candidate - the trace produced under one candidate edit.
 * @returns counted differences and a verdict.
 */
export function compareTraces(baseline: TraceSummary, candidate: TraceSummary): TraceDelta {
  const b: BehaviorMetrics = baseline.metrics
  const c: BehaviorMetrics = candidate.metrics

  const delta: TraceDelta = {
    toolErrors: c.toolErrors - b.toolErrors,
    repeatedToolCalls: c.repeatedToolCalls - b.repeatedToolCalls,
    steps: c.steps - b.steps,
    filesTouched: c.filesTouched - b.filesTouched,
    toolOutputChars: c.toolOutputChars - b.toolOutputChars,
    durationMs: c.durationMs - b.durationMs,
    completed: c.completed,
    improved: [],
    regressed: [],
    verdict: 'neutral'
  }

  // Hard safety gate first: nothing below can rescue these.
  if (b.completed && !c.completed) {
    delta.verdict = 'unsafe'
    delta.regressed.push('completed')
    return delta
  }
  const errorCeiling = b.toolErrors + Math.max(1, Math.floor(b.toolErrors * 0.5))
  if (c.toolErrors > errorCeiling) {
    delta.verdict = 'unsafe'
    delta.regressed.push('toolErrors')
    return delta
  }

  if (delta.toolErrors <= -1) delta.improved.push('toolErrors')
  else if (delta.toolErrors >= 1) delta.regressed.push('toolErrors')

  if (delta.repeatedToolCalls <= -1) delta.improved.push('repeatedToolCalls')
  else if (delta.repeatedToolCalls >= 2) delta.regressed.push('repeatedToolCalls')

  if (delta.steps <= -1) delta.improved.push('steps')
  else if (delta.steps >= STEP_REGRESSION && delta.improved.length === 0) delta.regressed.push('steps')

  if (b.toolOutputChars > 0 && delta.toolOutputChars <= -Math.ceil(b.toolOutputChars * OUTPUT_SAVING_RATIO)) {
    delta.improved.push('toolOutputChars')
  } else if (b.toolOutputChars > 0 && delta.toolOutputChars >= Math.ceil(b.toolOutputChars * OUTPUT_SAVING_RATIO)) {
    delta.regressed.push('toolOutputChars')
  }

  // More files touched only counts as progress when the turn actually closed:
  // otherwise it is churn, not productivity.
  if (delta.filesTouched >= 1 && c.completed) delta.improved.push('filesTouched')
  else if (delta.filesTouched <= -1 && b.filesTouched > 0) delta.regressed.push('filesTouched')

  if (delta.improved.length > 0 && delta.regressed.length === 0) delta.verdict = 'better'
  else if (delta.regressed.length > delta.improved.length) delta.verdict = 'worse'
  else if (delta.regressed.length > 0) delta.verdict = 'worse'
  else delta.verdict = 'neutral'

  return delta
}

/**
 * Whether a delta clears the configured improvement floor.
 *
 * @param delta - the comparison result.
 * @param minImprovement - how many metrics must have improved.
 */
export function meetsFloor(delta: TraceDelta, minImprovement: number): boolean {
  return delta.verdict === 'better' && delta.improved.length >= Math.max(1, minImprovement)
}

/**
 * One-line justification, used both in the run record and in experience
 * evidence. It states counts only - never a judgement about correctness.
 *
 * @param delta - the comparison result.
 * @returns a compact sentence.
 */
export function describeDelta(delta: TraceDelta): string {
  const parts: string[] = []
  if (delta.improved.length > 0) parts.push(`better on ${delta.improved.join(', ')}`)
  if (delta.regressed.length > 0) parts.push(`worse on ${delta.regressed.join(', ')}`)
  if (parts.length === 0) parts.push('no material difference')
  return `${delta.verdict}: ${parts.join('; ')}`
}

/**
 * Signed difference table for the run record; kept verbose on purpose so a
 * rejected candidate can be explained months later without replaying it.
 *
 * @param delta - the comparison result.
 */
export function deltaTable(delta: TraceDelta): Record<string, number | boolean> {
  return {
    toolErrors: delta.toolErrors,
    repeatedToolCalls: delta.repeatedToolCalls,
    steps: delta.steps,
    filesTouched: delta.filesTouched,
    toolOutputChars: delta.toolOutputChars,
    durationMs: delta.durationMs,
    completed: delta.completed
  }
}

/** Verdict ordering used when two candidates conflict on the same edit key. */
export const VERDICT_RANK: Record<DeltaVerdict, number> = {
  better: 3,
  neutral: 2,
  worse: 1,
  unsafe: 0
}
