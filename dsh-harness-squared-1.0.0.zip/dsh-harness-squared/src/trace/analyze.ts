/**
 * Turn an append-only session log into comparable behaviour.
 *
 * The analyzer is the plugin's only source of truth about what an execution
 * shell *did*. It reads the log defensively - every field it touches may be
 * absent in another DSH version - and it never interprets intent. What comes
 * out is a fixed set of counts plus the ordered tool sequence, which is enough
 * to answer the only question composition is allowed to ask: did this trace
 * behave differently, and in which direction?
 */

import { digestSequence } from '../util/text.js'
import { sanitizeInline } from '../util/redact.js'
import type { BehaviorMetrics, TraceSummary } from '../types.js'
import type { SessionEvent } from '../dsh.js'

/** Tools whose arguments name a filesystem target worth counting. */
const FILE_TOOLS = /(write|edit|patch|create|delete|remove|move|rename|bash|pwsh|shell|terminal)/i

const PATH_KEYS = ['path', 'file_path', 'filePath', 'absolutePath', 'target', 'file', 'notebook_path']

interface Block {
  type?: string
  text?: string
  name?: string
  id?: string
  arguments?: unknown
  input?: unknown
}

function blocksOf(message: unknown): Block[] {
  if (typeof message !== 'object' || message === null) return []
  const content = (message as { content?: unknown }).content
  if (Array.isArray(content)) return content as Block[]
  if (typeof content === 'string') return [{ type: 'text', text: content }]
  return []
}

function argsOf(block: Block): Record<string, unknown> {
  const raw = block.arguments ?? block.input
  if (typeof raw === 'string') {
    try {
      const parsed = JSON.parse(raw)
      return typeof parsed === 'object' && parsed !== null ? (parsed as Record<string, unknown>) : {}
    } catch {
      return {}
    }
  }
  return typeof raw === 'object' && raw !== null ? (raw as Record<string, unknown>) : {}
}

/** Stable key for repeat detection; argument order must not matter. */
function callKey(name: string, args: Record<string, unknown>): string {
  const keys = Object.keys(args).sort()
  const ordered: Record<string, unknown> = {}
  for (const key of keys) ordered[key] = args[key]
  try {
    return `${name}:${JSON.stringify(ordered)}`
  } catch {
    return `${name}:<unserialisable>`
  }
}

/**
 * Project one session log into metrics plus a trace digest.
 *
 * @param sessionId - the session the events came from.
 * @param events - the complete log, oldest first.
 * @returns the summary used by probes, composition and experience entries.
 */
export function analyzeTrace(sessionId: string, events: SessionEvent[]): TraceSummary {
  let steps = 0
  let toolCalls = 0
  let toolErrors = 0
  let repeated = 0
  let assistantChars = 0
  let toolOutputChars = 0
  let turnOpen = false
  let firstTime = Number.NaN
  let lastTime = Number.NaN
  const seenCalls = new Set<string>()
  const files = new Set<string>()
  const toolSequence: string[] = []
  const errorSamples: string[] = []

  for (const event of events) {
    if (Number.isFinite(event.time)) {
      if (!Number.isFinite(firstTime)) firstTime = event.time
      lastTime = event.time
    }
    const data = (event.data ?? {}) as Record<string, unknown>

    if (event.type === 'turn/start') {
      turnOpen = true
      continue
    }
    if (event.type === 'turn/end') {
      turnOpen = false
      continue
    }

    if (event.type === 'assistant/message') {
      steps += 1
      for (const block of blocksOf(data.message)) {
        if (block.type === 'text' && typeof block.text === 'string') assistantChars += block.text.length
        if (block.type !== 'tool-call') continue
        const name = typeof block.name === 'string' ? block.name : 'unknown'
        const args = argsOf(block)
        toolCalls += 1
        toolSequence.push(name)
        const key = callKey(name, args)
        if (seenCalls.has(key)) repeated += 1
        else seenCalls.add(key)
        if (FILE_TOOLS.test(name)) {
          for (const pathKey of PATH_KEYS) {
            const value = args[pathKey]
            if (typeof value === 'string' && value.length > 0 && value.length < 400) files.add(value)
          }
        }
      }
      continue
    }

    if (event.type === 'tool/result') {
      const message = data.message as { isError?: unknown; content?: unknown } | undefined
      const text = blocksOf(message)
        .map((block) => (typeof block.text === 'string' ? block.text : ''))
        .join('\n')
      toolOutputChars += text.length
      const failed = data.error !== undefined || message?.isError === true
      if (failed) {
        toolErrors += 1
        if (errorSamples.length < 3) {
          const raw = typeof data.error === 'object' && data.error !== null
            ? String((data.error as { message?: unknown }).message ?? '')
            : text
          const sample = sanitizeInline(raw.length > 0 ? raw : 'tool error', 120)
          if (sample.length > 0) errorSamples.push(sample)
        }
      }
    }
  }

  const metrics: BehaviorMetrics = {
    steps,
    toolCalls,
    toolErrors,
    repeatedToolCalls: repeated,
    filesTouched: files.size,
    assistantChars,
    toolOutputChars,
    completed: !turnOpen,
    durationMs: Number.isFinite(firstTime) && Number.isFinite(lastTime) ? Math.max(0, lastTime - firstTime) : 0,
    events: events.length
  }

  return {
    sessionId,
    metrics,
    toolSequence,
    errorSamples,
    digest: digestSequence(toolSequence)
  }
}

/**
 * Analyze the tail of a session starting at a sequence number.
 *
 * Probes record the log length they seeded with, so a forked child's inherited
 * prefix is not counted as work the candidate did.
 *
 * @param sessionId - the session id.
 * @param events - the complete log.
 * @param fromSeq - first sequence number to include.
 * @returns the summary of the selected window.
 */
export function analyzeFrom(sessionId: string, events: SessionEvent[], fromSeq: number): TraceSummary {
  return analyzeTrace(sessionId, events.filter((event) => event.seq >= fromSeq))
}
