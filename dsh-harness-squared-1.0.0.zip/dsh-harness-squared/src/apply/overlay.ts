/**
 * The active overlay: the shell patch that survived composition.
 *
 * This is the outer half of the recursion. A probe validates a change on one
 * agent; composition accepts it; the overlay then registers it on the *root*
 * context so every new step of every agent runs the improved shell. Sections
 * are held as disposers, so replacing the overlay is exact - the previous
 * generation disappears before the next one appears, with no duplicate names
 * and no leaked registrations.
 */

import { readFile } from 'node:fs/promises'
import { join } from 'node:path'

import { writeFileAtomic } from '../util/atomic.js'
import { nowIso } from '../util/text.js'
import type { HarnessSquaredConfig } from '../config.js'
import type { DshContext, Disposer } from '../dsh.js'
import type { ActiveOverlay } from '../types.js'

/** Prefix every generated section carries, so ownership is obvious in a prompt. */
const SECTION_PREFIX = 'harness-squared:'

export class OverlayManager {
  private readonly ctx: DshContext
  private readonly config: HarnessSquaredConfig
  private readonly logger: { warn(...args: unknown[]): void; info(...args: unknown[]): void }
  private disposers: Disposer[] = []
  private overlay: ActiveOverlay | null = null

  constructor(ctx: DshContext, config: HarnessSquaredConfig, logger: { warn(...args: unknown[]): void; info(...args: unknown[]): void }) {
    this.ctx = ctx
    this.config = config
    this.logger = logger
  }

  /** Absolute path of the persisted overlay. */
  get path(): string {
    return join(this.config.root, 'overlay.json')
  }

  /** The current overlay, if one has been loaded or accepted. */
  get current(): ActiveOverlay | null {
    return this.overlay
  }

  /**
   * Read `overlay.json` and register it. A missing or malformed file simply
   * leaves the shell unmodified - never an activation failure.
   */
  async load(): Promise<void> {
    try {
      const raw = JSON.parse(await readFile(this.path, 'utf8')) as ActiveOverlay
      if (!raw || !Array.isArray(raw.sections)) throw new Error('overlay has no sections')
      this.overlay = raw
      this.apply()
    } catch {
      this.overlay = null
    }
  }

  /**
   * Replace the overlay with a composed generation and register it.
   *
   * @param input - sections from composition plus the run that produced them.
   * @returns the stored overlay; an empty section list clears the overlay.
   */
  async commit(input: { sections: Array<{ name: string; order: number; text: string }>; runId: string; notes: string[] }): Promise<ActiveOverlay | null> {
    if (input.sections.length === 0) return this.overlay
    const overlay: ActiveOverlay = {
      revision: (this.overlay?.revision ?? 0) + 1,
      acceptedAt: nowIso(),
      runId: input.runId,
      sections: input.sections.map((section) => ({
        ...section,
        name: section.name.startsWith(SECTION_PREFIX) ? section.name : `${SECTION_PREFIX}${section.name}`
      })),
      notes: input.notes
    }
    this.overlay = overlay
    await writeFileAtomic(this.path, `${JSON.stringify(overlay, null, 2)}\n`)
    this.apply()
    return overlay
  }

  /** Dispose the current generation and register the current overlay. */
  apply(): void {
    this.dispose()
    const prompt = this.ctx.systemPrompt
    if (!prompt || !this.overlay) return
    for (const section of this.overlay.sections) {
      try {
        this.disposers.push(
          prompt.section({ name: section.name, order: section.order, text: section.text, interpolate: false })
        )
      } catch (error) {
        this.logger.warn(`harness-squared: overlay section "${section.name}" was not applied`, error)
      }
    }
    this.logger.info(`harness-squared: overlay revision ${this.overlay.revision} active (${this.overlay.sections.length} section(s))`)
  }

  /** Remove every registered section. */
  dispose(): void {
    for (const disposer of this.disposers) {
      try {
        disposer()
      } catch {
        /* a disposal that already ran is not an error */
      }
    }
    this.disposers = []
  }
}
