/**
 * Slash commands: the zero-token control surface.
 *
 * A command runs directly against the agent and creates no model message, so
 * `/harness2 status` costs nothing and is safe to type mid-task. That is why the
 * sidebar control bar talks to the plugin this way: the alternative would be a
 * Remote RPC namespace, and a third-party bundle cannot add one.
 */

import { service } from './util/services.js'
import type { CommandsService, DshContext, Disposer } from './dsh.js'
import type { ExperienceLibrary } from './store/library.js'
import type { OverlayManager } from './apply/overlay.js'
import type { PpcEngine } from './ppc/engine.js'
import type { HarnessSquaredConfig } from './config.js'

export interface CommandDeps {
  config: HarnessSquaredConfig
  library: ExperienceLibrary
  overlay: OverlayManager
  engine: PpcEngine
  version: string
  logger: { warn(...args: unknown[]): void }
}

/**
 * Register the `harness2` command.
 *
 * @param ctx - host context with `commands`.
 * @param deps - library, engine and overlay.
 * @returns the disposer, or an empty list when commands are not composed.
 */
export function registerCommands(ctx: DshContext, deps: CommandDeps): Disposer[] {
  // `ctx.commands` throws when the service is not in `inject`, so the guarded
  // resolver is the only safe way to ask whether this composition has commands.
  const commands = service<CommandsService>(ctx, 'commands')
  if (!commands) {
    deps.logger.warn('harness-squared: ctx.commands is absent, /harness2 will not be available')
    return []
  }

  try {
    return [
      commands.register({
        name: 'harness2',
        description: 'Harness² control: status, recall, optimize, forget',
        input: { hint: 'status | recall <query> | optimize [domain] | forget <id>' },
        async handler({ agent, rawInput }) {
          const [verb = 'status', ...rest] = rawInput.trim().split(/\s+/)
          const argument = rest.join(' ').trim()

          if (verb === '' || verb === 'status') {
            const stats = deps.library.stats()
            const overlay = deps.overlay.current
            const last = deps.engine.last
            return {
              kind: 'success' as const,
              text: [
                `dsh-harness-squared v${deps.version}`,
                `经验条目 ${stats.entries}（invariant ${stats.byKind.invariant} / domain ${stats.byKind.domain}），领域 ${stats.domains.join(', ') || '无'}`,
                `叠加层 ${overlay ? `r${overlay.revision}（${overlay.sections.length} 段，${overlay.acceptedAt}）` : '无'}`,
                `最近一次 PPC ${last ? `${last.id} ${last.outcome}：接受 ${last.accepted.length} / 拒绝 ${last.rejected.length}` : '无'}`,
                `路由 probe=${deps.config.ppc.probeModel.model} reflect=${deps.config.ppc.reflectModel.model}；预算 ${deps.config.ppc.maxCandidates}×${deps.config.ppc.maxRounds} 轮 / ${deps.config.ppc.tokenBudget} tok`,
                `库目录 ${deps.config.root}`
              ].join('\n')
            }
          }

          if (verb === 'recall') {
            if (argument.length === 0) return { kind: 'error' as const, text: '用法：/harness2 recall <任务描述>' }
            const matches = deps.library.search(argument, { limit: deps.config.recall.maxEntries, minScore: deps.config.recall.minScore })
            if (matches.length === 0) return { kind: 'success' as const, text: `没有条目达到匹配下限：${argument.slice(0, 60)}` }
            return {
              kind: 'success' as const,
              text: matches
                .map(({ entry, score }) => `${entry.id} [${entry.domain}] ${score.toFixed(2)} ${entry.title}`)
                .join('\n')
            }
          }

          if (verb === 'list') {
            const entries = deps.library.list()
            return {
              kind: 'success' as const,
              text: entries.length === 0
                ? '经验库为空。'
                : entries.map((entry) => `${entry.id} [${entry.domain}/${entry.kind}] ${entry.title}`).join('\n')
            }
          }

          if (verb === 'forget') {
            if (argument.length === 0) return { kind: 'error' as const, text: '用法：/harness2 forget <EXP-xxxx>' }
            const removed = await deps.library.remove(argument)
            return removed
              ? { kind: 'success' as const, text: `已删除 ${argument}` }
              : { kind: 'error' as const, text: `没有条目 ${argument}` }
          }

          if (verb === 'optimize') {
            const sessionId = (agent as { session?: { id?: string } } | undefined)?.session?.id
            if (typeof sessionId !== 'string') return { kind: 'error' as const, text: '当前没有可读取轨迹的会话。' }
            if (deps.engine.running) return { kind: 'error' as const, text: '已有一个 PPC 运行在进行中。' }
            // The run outlives the command: it is reported through status and the
            // run record, never by blocking the command line for minutes.
            void deps.engine
              .run({ sessionId, ...(argument.length > 0 ? { domain: argument } : {}) })
              .catch((error) => deps.logger.warn('harness-squared: background run failed', error))
            return {
              kind: 'success' as const,
              text: `已启动一次 PPC（${argument || '自动判定领域'}）。完成后用 /harness2 status 查看结论；过程记录在 ${deps.config.root}/runs。`
            }
          }

          return {
            kind: 'error' as const,
            text: `未知子命令 "${verb}"。可用：status | list | recall <query> | optimize [domain] | forget <id>`
          }
        }
      })
    ]
  } catch (error) {
    deps.logger.warn('harness-squared: could not register the /harness2 command', error)
    return []
  }
}
