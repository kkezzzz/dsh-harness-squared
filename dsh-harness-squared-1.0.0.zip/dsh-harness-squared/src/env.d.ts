/**
 * Ambient declarations for the Node built-ins this plugin uses.
 *
 * They are hand-written instead of pulling `@types/node` so the package builds
 * with nothing but `typescript` installed - the shipped `lib/` is prebuilt, and
 * a contributor rebuilding it should not need a second dependency tree. Every
 * declaration below mirrors the stable Node 20+ signature the runtime provides.
 */

declare module 'node:fs' {
  export function existsSync(path: string): boolean
  export function readFileSync(path: string, encoding: 'utf8'): string
  export function mkdirSync(path: string, options?: { recursive?: boolean }): void
}

declare module 'node:fs/promises' {
  export interface FileHandle {
    writeFile(data: string, encoding?: 'utf8'): Promise<void>
    sync(): Promise<void>
    close(): Promise<void>
  }
  export function mkdir(path: string, options?: { recursive?: boolean }): Promise<string | undefined>
  export function readFile(path: string, encoding: 'utf8'): Promise<string>
  export function writeFile(path: string, data: string, encoding?: 'utf8'): Promise<void>
  export function rename(from: string, to: string): Promise<void>
  export function rm(path: string, options?: { recursive?: boolean; force?: boolean }): Promise<void>
  export function unlink(path: string): Promise<void>
  export function readdir(path: string): Promise<string[]>
  export function stat(path: string): Promise<{ size: number; mtimeMs: number; isFile(): boolean; isDirectory(): boolean }>
  export function open(path: string, flags: 'w' | 'wx' | 'a'): Promise<FileHandle>
}

declare module 'node:path' {
  export function join(...parts: string[]): string
  export function dirname(path: string): string
  export function basename(path: string, suffix?: string): string
  export function resolve(...parts: string[]): string
  export function isAbsolute(path: string): boolean
  export const sep: string
}

declare module 'node:os' {
  export function homedir(): string
  export function tmpdir(): string
}

declare module 'node:crypto' {
  export function createHash(algorithm: 'sha1' | 'sha256'): {
    update(data: string, inputEncoding?: 'utf8'): unknown
    digest(encoding: 'hex'): string
  }
  export function randomUUID(): string
}

/** The single AbortSignal member this plugin reads. */
interface AbortSignal {
  readonly aborted: boolean
}

/** Timers, as the host runtime provides them. */
declare function setTimeout(handler: () => void, timeout?: number): unknown
declare function clearTimeout(handle: unknown): void
