/**
 * dsh-harness-squared - Harness² for DeepSeek Harness.
 *
 * What this bundle adds to a DSH installation, in one paragraph: an execution
 * shell that optimizes itself. Each run reads an append-only trace, proposes
 * shell edits from counted behavioural signals, probes every candidate in an
 * isolated child session, keeps only what measurably improved the trace, applies
 * the survivors to the root prompt, and stores the result as a domain-scoped
 * experience entry that later turns can recall.
 *
 * Nothing here scores an answer or compares against a reference trajectory. The
 * only evaluation is `trace/compare.ts`, and the only thing a change can touch is
 * the shell: prompt sections, model routing, budgets.
 *
 * Lifecycle: every registration is owned by a `ctx.effect`. Unloading the row
 * disposes the prompt sections, the tools, the command, the listeners and the
 * overlay in one pass, and leaves the experience library on disk untouched -
 * that independence is asserted by `test/run.mjs`.
 *
 * @module dsh-harness-squared
 */

import { ConfigSchema, DEFAULT_CONFIG, resolveConfig } from './config.js'
import { ExperienceLibrary } from './store/library.js'
import { OverlayManager } from './apply/overlay.js'
import { StatusStore } from './status.js'
import { PpcEngine } from './ppc/engine.js'
import { registerRecall } from './recall/inject.js'
import { registerTools } from './tools.js'
import { registerCommands } from './commands.js'
import { distillTurn } from './distill/reflect.js'
import { analyzeTrace } from './trace/analyze.js'
import { service } from './util/services.js'
import type { DshContext, Disposer, SessionEvent } from './dsh.js'
import type { PpcRunRecord } from './types.js'

/**
 * Reported version. Kept as a literal so activation never depends on reading a
 * file; `test/run.mjs` asserts it matches package.json.
 */
export const VERSION = '1.0.0'

/** Loader-visible plugin name; matches the patch row id. */
export const name = 'harness-squared'

/**
 * Exported schema.
 *
 * Cordis validates plugin config through Standard Schema
 * (`Config['~standard'].validate`), which is why this is a schema object rather
 * than the defaults map: a plain object crashes the fiber before `apply` runs.
 * {@link ConfigSchema} implements the contract directly, so no validation
 * library has to resolve from a profile's `node_modules`.
 */
export const Config = ConfigSchema

/**
 * The documented defaults, exported for tests and for the README's tables.
 * Not what the loader consumes - see {@link Config}.
 */
export { DEFAULT_CONFIG }

/**
 * Hard dependencies.
 *
 * Both are core to any agent composition, and both are needed *during* `apply`
 * (tools to register, systemPrompt to add sections). Everything else - sessions,
 * agents, commands - is resolved lazily so a thinner composition still boots.
 */
export const inject = ['tools', 'systemPrompt']

/**
 * Mount the plugin.
 *
 * @param ctx - host context.
 * @param raw - loader configuration; anything missing falls back to defaults.
 */
export async function apply(ctx: DshContext, raw?: unknown): Promise<void> {
  const config = resolveConfig(raw)
  const logger = ctx.logger

  if (!config.enabled) {
    logger.info('harness-squared: disabled by configuration (enabled=false); nothing registered')
    return
  }

  const library = new ExperienceLibrary(config.root)
  await library.open()

  const overlay = new OverlayManager(ctx, config, logger)
  await overlay.load()

  const status = new StatusStore(config.root, VERSION)
  let engine: PpcEngine | undefined

  const flush = async (record?: PpcRunRecord): Promise<void> => {
    await status.write(
      status.build({
        config,
        library: library.stats(),
        overlay: overlay.current,
        lastRun: record ?? engine?.last ?? null
      })
    )
  }

  engine = new PpcEngine({
    ctx,
    config,
    library,
    overlay,
    logger,
    onSettled: async (record) => {
      await flush(record)
    }
  })

  const disposers: Disposer[] = []
  const collect = (list: Disposer[]): void => {
    for (const disposer of list) disposers.push(disposer)
  }

  collect(
    registerRecall(ctx, {
      library,
      config,
      logger
    })
  )
  collect(registerTools(ctx, { config, library, overlay, engine, version: VERSION, logger }))
  collect(registerCommands(ctx, { config, library, overlay, engine, version: VERSION, logger }))

  // The turn-end reflection hook. It observes `session/event` instead of
  // intercepting `agent/turn-stopping`, so it can never delay a turn: the work
  // is queued and runs after the turn has already closed.
  if (config.distill.enabled && config.distill.onTurnEnd) {
    const inFlight = new Set<string>()
    collect([
      ctx.on('session/event', (sessionId: string, event: SessionEvent) => {
        if (event?.type !== 'turn/end') return
        if (inFlight.has(sessionId)) return
        inFlight.add(sessionId)
        setTimeout(() => {
          void reflectOnTurn(sessionId)
            .catch((error) => logger.warn('harness-squared: turn reflection failed', error))
            .finally(() => inFlight.delete(sessionId))
        }, 0)
      })
    ])

    const reflectOnTurn = async (sessionId: string): Promise<void> => {
      const sessions = service<{ get(id: string): { id: string; snapshotEvents(): SessionEvent[] } | undefined }>(ctx, 'sessions')
      const session = sessions?.get(sessionId)
      if (!session) return
      const events = session.snapshotEvents()
      const lastStart = [...events].reverse().find((event) => event.type === 'turn/start')
      const window = lastStart ? events.filter((event) => event.seq >= lastStart.seq) : events
      const trace = analyzeTrace(sessionId, window)
      const task = lastUserTextOf(window)
      if (!task) return
      const declared = [...new Set([...config.domains, ...library.stats().domains])]
      const entry = distillTurn({ task, domain: inferDomainOf(task, declared), trace, config })
      if (!entry) return
      await library.upsert(entry)
      await flush()
    }
  }

  ctx.effect(
    () => () => {
      for (const disposer of disposers) {
        try {
          disposer()
        } catch {
          /* disposal is best effort; the fiber is going away regardless */
        }
      }
    },
    'harness-squared: registrations'
  )

  ctx.effect(() => () => overlay.dispose(), 'harness-squared: overlay sections')

  await flush()
  logger.info(
    `harness-squared v${VERSION} loaded: root=${config.root}, entries=${library.stats().entries}, ` +
      `overlay=${overlay.current ? `r${overlay.current.revision}` : 'none'}, tools=4, command=/harness2`
  )
}

/** The last user message in a window of events. */
function lastUserTextOf(events: SessionEvent[]): string | undefined {
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index]
    if (event?.type !== 'user/message') continue
    const content = (event.data as { message?: { content?: unknown } } | undefined)?.message?.content
    if (typeof content === 'string') return content
    if (!Array.isArray(content)) continue
    const text = content
      .map((block: { type?: string; text?: unknown }) => (block?.type === 'text' && typeof block.text === 'string' ? block.text : ''))
      .join('\n')
      .trim()
    if (text.length > 0) return text
  }
  return undefined
}

/** Local import shim so the reflection hook does not pull the library's graph. */
function inferDomainOf(task: string, declared: string[]): string {
  if (declared.length === 0) return 'general'
  const lower = task.toLowerCase()
  for (const domain of declared) {
    if (lower.includes(domain.toLowerCase())) return domain
  }
  return 'general'
}
