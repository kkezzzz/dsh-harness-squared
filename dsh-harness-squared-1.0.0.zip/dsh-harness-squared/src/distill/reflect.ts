/**
 * Distillation: turn a validated change into a reusable experience.
 *
 * Only composition's accepted candidates become entries, and every entry keeps
 * the numbers that admitted it. That is what makes the library auditable: a
 * reader can disagree with an entry and see exactly which trace difference it
 * rests on, without replaying anything.
 *
 * A turn-level hook exists too, but it records *observations* rather than shell
 * edits, and only for turns that finished cleanly and produced files - a turn
 * that failed is evidence for a probe, not a lesson to inject into the next one.
 */

import { sanitize, sanitizeInline } from '../util/redact.js'
import { nowIso, oneLine, tokenize } from '../util/text.js'
import type { HarnessSquaredConfig } from '../config.js'
import type { Candidate, ExperienceEntry, TraceDelta, TraceSummary } from '../types.js'

export interface DistillRunInput {
  runId: string
  task: string
  domain: string
  baseline: TraceSummary
  accepted: Array<{ candidate: Candidate; delta: TraceDelta; summary: string }>
  config: HarnessSquaredConfig
}

/**
 * Build one experience entry per accepted candidate.
 *
 * @param input - run identity, task, baseline and accepted candidates.
 * @returns entries ready for `library.upsert`.
 */
export function distillRun(input: DistillRunInput): ExperienceEntry[] {
  const max = input.config.evidence.maxChars
  return input.accepted.map(({ candidate, delta, summary }) => {
    const section = candidate.edits.find((edit) => edit.op === 'append-prompt-section')
    const change = section && section.op === 'append-prompt-section' ? section.text : '(routing change only)'
    const reusable = reusableTokens(input.task)

    return {
      id: '',
      domain: input.domain,
      kind: candidate.kind,
      title: `${input.domain}: ${oneLine(candidate.hypothesis).slice(0, 80)}`,
      situation: sanitize(
        [
          `任务：${oneLine(input.task).slice(0, 240)}`,
          `基线轨迹：${input.baseline.toolSequence.slice(0, 10).join(' → ') || '(no tool calls)'}`,
          `触发信号：${candidate.signal}`
        ].join('\n'),
        max
      ),
      change: sanitize(change, max),
      evidence: sanitize(evidenceText(input.baseline, delta, summary), max),
      reuse: reusable,
      confidence: Math.min(0.9, 0.45 + delta.improved.length * 0.15),
      origin: 'ppc',
      createdAt: nowIso(),
      tags: [input.domain, candidate.kind, ...reusable.slice(0, 4)].filter((tag, index, all) => all.indexOf(tag) === index)
    }
  })
}

/** The counted before/after table used as evidence. */
export function evidenceText(baseline: TraceSummary, delta: TraceDelta, summary: string): string {
  const b = baseline.metrics
  const c = {
    toolErrors: b.toolErrors + delta.toolErrors,
    repeatedToolCalls: b.repeatedToolCalls + delta.repeatedToolCalls,
    steps: b.steps + delta.steps,
    filesTouched: b.filesTouched + delta.filesTouched,
    toolOutputChars: b.toolOutputChars + delta.toolOutputChars
  }
  return [
    `行为对比（基线 → 候选）：`,
    `- 工具错误：${b.toolErrors} → ${c.toolErrors}`,
    `- 重复调用：${b.repeatedToolCalls} → ${c.repeatedToolCalls}`,
    `- 步数：${b.steps} → ${c.steps}`,
    `- 涉及文件：${b.filesTouched} → ${c.filesTouched}`,
    `- 工具输出字符：${b.toolOutputChars} → ${c.toolOutputChars}`,
    `- 结论：${summary}`
  ].join('\n')
}

export interface DistillTurnInput {
  task: string
  domain: string
  trace: TraceSummary
  config: HarnessSquaredConfig
}

/**
 * Record a clean, productive turn as a situational observation.
 *
 * @param input - the turn's task, domain and analysed trace.
 * @returns an entry, or `undefined` when the turn taught nothing.
 */
export function distillTurn(input: DistillTurnInput): ExperienceEntry | undefined {
  const m = input.trace.metrics
  if (!m.completed) return undefined
  if (m.toolErrors > 0) return undefined
  if (m.filesTouched === 0) return undefined
  if (m.toolCalls === 0) return undefined

  const reusable = reusableTokens(input.task)
  return {
    id: '',
    domain: input.domain,
    kind: 'domain',
    title: `${input.domain}: 成功轨迹形态（${m.steps} 步 / ${m.toolCalls} 次调用）`,
    situation: sanitize(
      [`任务：${oneLine(input.task).slice(0, 240)}`, `轨迹：${input.trace.toolSequence.slice(0, 12).join(' → ')}`].join('\n'),
      input.config.evidence.maxChars
    ),
    change: sanitize(
      [
        '观察（未经验证，仅描述该领域成功轨迹的形状）：',
        `- 先 ${input.trace.toolSequence[0] ?? '(none)'}，共产出 ${m.filesTouched} 个文件`,
        `- 全程 ${m.toolCalls} 次调用、0 次错误、${m.steps} 步收尾`
      ].join('\n'),
      input.config.evidence.maxChars
    ),
    evidence: sanitize(
      `该轮完整结束（completed=true），工具错误 0，涉及文件 ${m.filesTouched}，工具输出 ${m.toolOutputChars} 字符。`,
      input.config.evidence.maxChars
    ),
    reuse: reusable,
    confidence: 0.35,
    origin: 'distill',
    createdAt: nowIso(),
    tags: [input.domain, 'observation', ...reusable.slice(0, 4)]
  }
}

/** Retrieval triggers: the task's most distinctive tokens. */
function reusableTokens(task: string): string[] {
  return tokenize(task)
    .filter((token) => token.length >= 2)
    .slice(0, 6)
    .map((token) => sanitizeInline(token, 24))
}
