/**
 * The PPC engine: Propose -> Probe -> Compose, then commit what survived.
 *
 * One run is a bounded, resumable-by-record operation:
 *
 *   baseline trace  ->  proposals  ->  N isolated probes  ->  composition
 *                   ->  overlay commit  ->  experience entries  ->  run record
 *
 * Every stage is allowed to produce nothing, and the run still ends with a
 * record explaining why. That matters more than a high acceptance rate: an
 * optimizer that cannot say "no change was justified" is not safe to leave on.
 *
 * Concurrency: one run per plugin instance. A second request returns the current
 * run's refusal instead of queueing, because two concurrent optimizations would
 * fight over the same overlay generation.
 */

import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'

import { analyzeTrace } from '../trace/analyze.js'
import { nowIso, oneLine } from '../util/text.js'
import { writeFileAtomic } from '../util/atomic.js'
import { sanitizeInline } from '../util/redact.js'
import { service } from '../util/services.js'
import { inferDomain } from '../store/library.js'
import { proposeCandidates } from './propose.js'
import { runProbe } from './probe.js'
import { compose } from './compose.js'
import { Budget, estimateTraceTokens } from './budget.js'
import { distillRun } from '../distill/reflect.js'
import type { HarnessSquaredConfig } from '../config.js'
import type { AgentsService, DshContext, SessionsService, SessionEvent } from '../dsh.js'
import type { ExperienceLibrary } from '../store/library.js'
import type { OverlayManager } from '../apply/overlay.js'
import type { PpcRunRecord, TraceSummary } from '../types.js'
import type { ProbeOutcome } from './probe.js'

export interface EngineDeps {
  ctx: DshContext
  config: HarnessSquaredConfig
  library: ExperienceLibrary
  overlay: OverlayManager
  logger: { warn(...args: unknown[]): void; info(...args: unknown[]): void }
  /** Called after a run settles, so the status snapshot can refresh. */
  onSettled?: (record: PpcRunRecord) => void | Promise<void>
}

export interface RunInput {
  sessionId: string
  /** Task text; defaults to the session's last user message. */
  task?: string
  /** Domain override; defaults to lexical inference. */
  domain?: string
}

export class PpcEngine {
  private readonly deps: EngineDeps
  private busy = false
  private lastRun: PpcRunRecord | null = null

  constructor(deps: EngineDeps) {
    this.deps = deps
  }

  /** Whether a run is in flight. */
  get running(): boolean {
    return this.busy
  }

  /** The most recent run in this process. */
  get last(): PpcRunRecord | null {
    return this.lastRun
  }

  /**
   * Run one Propose-Probe-Compose cycle.
   *
   * @param input - the session to learn from, plus optional task/domain.
   * @returns the run record, also written under `<root>/runs/`.
   */
  async run(input: RunInput): Promise<PpcRunRecord> {
    const startedAt = nowIso()
    const runId = `RUN-${startedAt.replace(/[-:]/g, '').slice(0, 15)}-${randomUUID().slice(0, 6)}`
    const { ctx, config, library, overlay, logger } = this.deps

    if (this.busy) {
      const busyRecord = this.record(runId, startedAt, input, {
        domain: input.domain ?? 'general',
        task: input.task ?? '',
        baselineSessionId: input.sessionId,
        outcome: 'error',
        note: 'another PPC run is already in flight in this process'
      })
      return busyRecord
    }
    this.busy = true

    try {
      const sessions = service<SessionsService>(ctx, 'sessions')
      if (!sessions) throw new Error('the sessions service is not mounted')
      if (!service<AgentsService>(ctx, 'agents')) throw new Error('the agents service is not mounted')
      if (!config.ppc.enabled) throw new Error('ppc is disabled in the plugin configuration')

      const session = sessions.get(input.sessionId)
      if (!session) throw new Error(`session "${input.sessionId}" is not live`)
      const events: SessionEvent[] = session.snapshotEvents()
      const baseline = analyzeTrace(input.sessionId, events)
      const task = sanitizeInline(input.task ?? lastUserText(events) ?? '', 1200)

      const declared = [...new Set([...config.domains, ...library.stats().domains])]
      const domain = input.domain ?? inferDomain(task, declared)

      const budget = new Budget({
        maxCandidates: config.ppc.maxCandidates,
        maxRounds: config.ppc.maxRounds,
        tokenBudget: config.ppc.tokenBudget
      })

      const proposals = proposeCandidates({
        baseline,
        task,
        domain,
        maxCandidates: config.ppc.maxCandidates,
        existingSections: overlay.current?.sections.map((section) => section.name) ?? [],
        known: library.list().filter((entry) => entry.domain === domain)
      })

      if (proposals.length === 0) {
        return await this.settle(
          this.record(runId, startedAt, input, {
            domain,
            task,
            baselineSessionId: input.sessionId,
            outcome: 'no-candidate',
            note: `no behavioural signal justified an edit (errors ${baseline.metrics.toolErrors}, repeats ${baseline.metrics.repeatedToolCalls}, steps ${baseline.metrics.steps}, files ${baseline.metrics.filesTouched})`
          })
        )
      }

      const sandboxRoot = join(config.root, 'sandboxes')
      await mkdir(sandboxRoot, { recursive: true })

      const outcomes: ProbeOutcome[] = []
      for (const candidate of proposals) {
        if (!budget.canProbe()) break
        budget.countProbe()
        // The probe re-reads a trace the size of the baseline, so the baseline's
        // own weight is the honest pre-charge.
        budget.charge(estimateTraceTokens(events))
        const outcome = await runProbe(
          { ctx, config, sandboxRoot },
          {
            candidate,
            task,
            baselineSessionId: input.sessionId,
            baselineEventCount: events.length
          }
        )
        if (outcome.trace) budget.charge(outcome.trace.metrics.events + outcome.trace.metrics.toolOutputChars / 4)
        outcomes.push(outcome)
        logger.info(`harness-squared: probe ${candidate.id} -> ${outcome.ok ? 'trace captured' : outcome.reason}`)
      }

      const composed = compose({
        baseline,
        proposals,
        outcomes,
        minImprovement: config.ppc.minImprovement
      })

      let committed: string | null = null
      if (composed.accepted.length > 0) {
        const stored = await overlay.commit({
          sections: composed.sections,
          runId,
          notes: composed.notes
        })
        committed = stored ? `${stored.sections.length} section(s) at revision ${stored.revision}` : null

        const entries = distillRun({
          runId,
          task,
          domain,
          baseline,
          accepted: composed.accepted,
          config
        })
        for (const entry of entries) {
          try {
            await library.upsert(entry)
          } catch (error) {
            logger.warn('harness-squared: could not store an experience entry', error)
          }
        }
      }

      const record = this.record(runId, startedAt, input, {
        domain,
        task,
        baselineSessionId: input.sessionId,
        proposed: proposals.length,
        probed: outcomes.length,
        accepted: composed.accepted.map((entry) => entry.candidate.id),
        rejected: composed.rejected,
        estimatedTokens: budget.snapshot().used,
        outcome: budget.reason === 'budget' && composed.accepted.length === 0 ? 'budget' : 'ok',
        note: buildNote(composed, committed, budget.snapshot().used, config.ppc.tokenBudget)
      })

      return await this.settle(record)
    } catch (error) {
      logger.warn('harness-squared: PPC run failed', error)
      return await this.settle(
        this.record(runId, startedAt, input, {
          domain: input.domain ?? 'general',
          task: input.task ?? '',
          baselineSessionId: input.sessionId,
          outcome: 'error',
          note: error instanceof Error ? error.message : String(error)
        })
      )
    } finally {
      this.busy = false
    }
  }

  /** Persist the record, notify the host and return it. */
  private async settle(record: PpcRunRecord): Promise<PpcRunRecord> {
    this.lastRun = record
    try {
      await writeFileAtomic(join(this.deps.config.root, 'runs', `${record.id}.json`), `${JSON.stringify(record, null, 2)}\n`)
    } catch (error) {
      this.deps.logger.warn('harness-squared: could not write the run record', error)
    }
    try {
      await this.deps.onSettled?.(record)
    } catch {
      /* status is a convenience surface */
    }
    return record
  }

  /** Fill the record's defaults. */
  private record(
    runId: string,
    startedAt: string,
    input: RunInput,
    patch: Partial<PpcRunRecord> & Pick<PpcRunRecord, 'domain' | 'task' | 'baselineSessionId' | 'outcome'>
  ): PpcRunRecord {
    return {
      id: runId,
      startedAt,
      finishedAt: nowIso(),
      domain: patch.domain,
      task: oneLine(patch.task).slice(0, 400),
      baselineSessionId: patch.baselineSessionId,
      proposed: patch.proposed ?? 0,
      probed: patch.probed ?? 0,
      accepted: patch.accepted ?? [],
      rejected: patch.rejected ?? [],
      estimatedTokens: patch.estimatedTokens ?? 0,
      outcome: patch.outcome,
      note: patch.note ?? ''
    }
  }
}

/** The last user message in a log, used when no task was supplied. */
export function lastUserText(events: SessionEvent[]): string | undefined {
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index]
    if (event?.type !== 'user/message') continue
    const content = (event.data as { message?: { content?: unknown } } | undefined)?.message?.content
    if (typeof content === 'string') return content
    if (!Array.isArray(content)) continue
    const text = content
      .map((block: { type?: string; text?: unknown }) => (block?.type === 'text' && typeof block.text === 'string' ? block.text : ''))
      .join('\n')
      .trim()
    if (text.length > 0) return text
  }
  return undefined
}

/** Compose the run's one-line explanation. */
function buildNote(
  composed: ReturnType<typeof compose>,
  committed: string | null,
  spent: number,
  budget: number
): string {
  const parts = [
    `${composed.accepted.length} accepted / ${composed.rejected.length} rejected`,
    committed ? `overlay: ${committed}` : 'overlay unchanged',
    `spent ≈${spent} of ${budget} tokens`
  ]
  if (composed.notes.length > 0) parts.push(composed.notes.join(' | '))
  return parts.join('; ')
}

/** Re-export so tools can describe a failed baseline without importing the analyzer. */
export type { TraceSummary }
