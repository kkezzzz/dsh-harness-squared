/**
 * Compose: decide what survives.
 *
 * Composition is the only place that can accept a change, and it accepts on
 * evidence alone:
 *
 *   1. a candidate with no trace is rejected (its probe never produced
 *      behaviour to compare);
 *   2. an `unsafe` verdict is rejected outright - a shell that stops finishing
 *      turns never gets averaged against one that finishes cheaply;
 *   3. a candidate must clear the configured improvement floor;
 *   4. two survivors that edit the same section are reconciled by keeping the
 *      one with more improved metrics, and the loser is recorded with a reason
 *      rather than dropped silently.
 *
 * Nothing here asks a model whether a change is good. The optional reflection
 * model in the config is used to *summarise* accepted evidence into prose for
 * the experience library; it cannot accept or reject.
 */

import { compareTraces, describeDelta, meetsFloor } from '../trace/compare.js'
import type { Candidate, Rejection, TraceDelta, TraceSummary } from '../types.js'
import type { ProbeOutcome } from './probe.js'

export interface ComposedSection {
  name: string
  order: number
  text: string
}

export interface AcceptedCandidate {
  candidate: Candidate
  delta: TraceDelta
  /** Human-readable summary of the counted difference. */
  summary: string
}

export interface ComposeResult {
  accepted: AcceptedCandidate[]
  rejected: Rejection[]
  sections: ComposedSection[]
  notes: string[]
}

export interface ComposeInput {
  baseline: TraceSummary
  proposals: Candidate[]
  outcomes: ProbeOutcome[]
  minImprovement: number
}

/**
 * Reconcile every proposal against the evidence gathered for it.
 *
 * @param input - baseline, proposals and probe outcomes.
 * @returns the accepted set, the rejections with reasons, and the merged sections.
 */
export function compose(input: ComposeInput): ComposeResult {
  const rejected: Rejection[] = []
  const notes: string[] = []
  const byId = new Map(input.outcomes.map((outcome) => [outcome.candidateId, outcome]))
  const survivors: AcceptedCandidate[] = []

  for (const candidate of input.proposals) {
    const outcome = byId.get(candidate.id)
    if (!outcome) {
      rejected.push({ candidateId: candidate.id, reason: 'not-probed: the run stopped before this candidate was executed' })
      continue
    }
    if (!outcome.ok || !outcome.trace) {
      rejected.push({
        candidateId: candidate.id,
        reason: `probe-failed: ${outcome.reason ?? 'unknown'}${outcome.detail ? ` (${outcome.detail})` : ''}`
      })
      continue
    }

    const delta = compareTraces(input.baseline, outcome.trace)
    const summary = describeDelta(delta)

    if (delta.verdict === 'unsafe') {
      rejected.push({ candidateId: candidate.id, reason: `regression-rejected: ${summary}` })
      notes.push(`${candidate.id} rejected as unsafe: ${summary}`)
      continue
    }
    if (!meetsFloor(delta, input.minImprovement)) {
      rejected.push({ candidateId: candidate.id, reason: `below-improvement-floor: ${summary}` })
      continue
    }
    survivors.push({ candidate, delta, summary })
  }

  // Reconcile conflicts: same section name means the two edits cannot both apply.
  const kept = new Map<string, AcceptedCandidate>()
  for (const survivor of survivors) {
    const key = sectionKey(survivor.candidate)
    const current = kept.get(key)
    if (!current) {
      kept.set(key, survivor)
      continue
    }
    const better =
      survivor.delta.improved.length > current.delta.improved.length ||
      (survivor.delta.improved.length === current.delta.improved.length &&
        survivor.delta.regressed.length < current.delta.regressed.length)
    const winner = better ? survivor : current
    const loser = better ? current : survivor
    kept.set(key, winner)
    rejected.push({
      candidateId: loser.candidate.id,
      reason: `conflict: superseded by ${winner.candidate.id} on ${key}`
    })
    notes.push(`${winner.candidate.id} wins the ${key} conflict against ${loser.candidate.id}`)
  }

  const accepted = [...kept.values()].sort((a, b) => a.candidate.id.localeCompare(b.candidate.id))
  const sections = accepted
    .flatMap((entry) =>
      entry.candidate.edits
        .filter((edit) => edit.op === 'append-prompt-section')
        .map((edit) => ({ name: edit.name, order: edit.order, text: edit.text }))
    )
    .sort((a, b) => a.order - b.order || a.name.localeCompare(b.name))

  return { accepted, rejected, sections, notes }
}

/** The identity two edits compete over. */
function sectionKey(candidate: Candidate): string {
  const section = candidate.edits.find((edit) => edit.op === 'append-prompt-section')
  if (section && section.op === 'append-prompt-section') return section.name
  const routing = candidate.edits.find((edit) => edit.op !== 'append-prompt-section')
  return routing ? routing.op : candidate.id
}
