/**
 * Propose: turn observed behaviour into candidate shell edits.
 *
 * Candidates are generated from *counted* observations in the baseline trace,
 * never from an opinion about what the model should have done. Each candidate
 * carries the signal that produced it, so a rejected candidate can still be
 * explained by pointing at the number it answered.
 *
 * Two kinds exist because they answer different risks:
 *
 * - `invariant` - the lesson should hold everywhere (do not repeat an identical
 *   call, verify before writing). It is proposed only when the trace shows the
 *   corresponding pathology.
 * - `domain` - the lesson is tied to a capability bucket (frontend, migration,
 *   data analysis). It exists so an invariant that only helps one domain can be
 *   scoped there instead of contaminating the rest, which is why it is ordered
 *   ahead of the lowest-value invariant when the candidate budget is tight.
 */

import { sanitizeInline } from '../util/redact.js'
import type { Candidate, ExperienceEntry, HarnessEdit, TraceSummary } from '../types.js'

/** Tools whose repetition is worth a dedicated rule. */
const REPEAT_THRESHOLD = 2

/** Below this many steps a trace has not explored enough to learn from. */
const MIN_STEPS_FOR_EFFICIENCY = 3

/** The prefix every generated section carries once it reaches the overlay. */
const SECTION_PREFIX = 'harness-squared:'

export interface ProposeInput {
  baseline: TraceSummary
  task: string
  domain: string
  /** Hard cap from config. */
  maxCandidates: number
  /** Section names already accepted, with or without the bundle prefix. */
  existingSections?: string[]
  /** Entries the library already holds for this domain. */
  known?: ExperienceEntry[]
}

/**
 * Build the candidate set for one baseline trace.
 *
 * @param input - baseline trace, task, domain and limits.
 * @returns candidates in priority order, never more than the cap.
 */
export function proposeCandidates(input: ProposeInput): Candidate[] {
  const { baseline, domain } = input
  const metrics = baseline.metrics
  const existing = new Set((input.existingSections ?? []).map(bareName))
  const possible: Candidate[] = []

  if (metrics.toolErrors > 0) {
    const samples = baseline.errorSamples.length > 0
      ? baseline.errorSamples.map((sample) => `- ${sample}`).join('\n')
      : '- (no error text was recorded)'
    possible.push({
      id: 'C1-errors',
      kind: 'invariant',
      domain: '*',
      hypothesis:
        'Requiring a pre-flight check of tool arguments before the first failing call removes the recorded errors without adding steps.',
      signal: `${metrics.toolErrors} tool error(s) in ${metrics.toolCalls} call(s)`,
      edits: [
        section('invariant:verify-before-call', 11810, [
          'Before a tool call that writes or executes, confirm the target exists and the arguments are complete.',
          'If a call fails, change one input before retrying; do not resend the same arguments.',
          'Errors recorded by the previous run in this domain:',
          samples
        ].join('\n'), false)
      ]
    })
  }

  if (metrics.repeatedToolCalls >= REPEAT_THRESHOLD) {
    possible.push({
      id: 'C2-repeats',
      kind: 'invariant',
      domain: '*',
      hypothesis:
        'Naming the repetition explicitly makes the shell widen its search instead of re-issuing identical calls.',
      signal: `${metrics.repeatedToolCalls} repeated call(s) with identical arguments`,
      edits: [
        section('invariant:no-identical-retry', 11820, [
          'Never issue two calls with identical arguments in one turn.',
          'When a result was already obtained, reuse it; when it was insufficient, change the query or the tool.'
        ].join('\n'), false)
      ]
    })
  }

  if (domain !== 'general') {
    const known = (input.known ?? []).filter((entry) => entry.domain === domain)
    possible.push({
      id: 'C4-domain',
      kind: 'domain',
      domain,
      hypothesis:
        'A domain-scoped clause keeps the general rules from being widened by feedback that only applies to this capability.',
      signal: known.length > 0
        ? `${known.length} existing experience entr(ies) in domain "${domain}"`
        : `domain "${domain}" is declared but holds no experience yet`,
      edits: [
        section(`domain:${domain}`, 11840, [
          `This task belongs to the "${domain}" domain.`,
          'Apply the general rules above, but treat conventions recorded for this domain as authoritative here:',
          known.length > 0
            ? known.slice(0, 3).map((entry) => `- ${sanitizeInline(entry.title, 90)}: ${sanitizeInline(entry.change, 160)}`).join('\n')
            : '- (none recorded yet)'
        ].join('\n'), true)
      ]
    })
  }

  if (metrics.steps >= MIN_STEPS_FOR_EFFICIENCY && metrics.filesTouched === 0) {
    possible.push({
      id: 'C3-no-side-effect',
      kind: 'invariant',
      domain: '*',
      hypothesis:
        'Asking for the concrete artefact before exploring reduces redundant steps in turns that produced no file changes.',
      signal: `${metrics.steps} step(s) with zero file side effects`,
      edits: [
        section('invariant:artefact-first', 11830, [
          'For a task that must produce or change files, name the exact path of the first artefact before the first tool call.',
          'Keep exploration proportional to that artefact; stop once it exists and is verified.'
        ].join('\n'), false)
      ]
    })
  }

  return possible.filter((candidate) => !alreadyApplied(candidate, existing)).slice(0, Math.max(1, input.maxCandidates))
}

/** Shorthand for a prompt-section edit. */
function section(name: string, order: number, text: string, scoped: boolean): HarnessEdit {
  return { op: 'append-prompt-section', name, order, text, scoped }
}

/** Strip the bundle prefix so overlay names and edit names compare equal. */
function bareName(name: string): string {
  return name.startsWith(SECTION_PREFIX) ? name.slice(SECTION_PREFIX.length) : name
}

/** Whether every section this candidate would add is already in force. */
function alreadyApplied(candidate: Candidate, existing: Set<string>): boolean {
  const names = candidate.edits
    .filter((edit) => edit.op === 'append-prompt-section')
    .map((edit) => (edit.op === 'append-prompt-section' ? bareName(edit.name) : ''))
  if (names.length === 0) return false
  return names.every((name) => existing.has(name))
}

/**
 * Whether a candidate would change anything at all.
 *
 * @param candidate - the candidate under test.
 * @param existingSections - names already in force, prefixed or not.
 */
export function isNovel(candidate: Candidate, existingSections: string[]): boolean {
  return !alreadyApplied(candidate, new Set(existingSections.map(bareName)))
}
