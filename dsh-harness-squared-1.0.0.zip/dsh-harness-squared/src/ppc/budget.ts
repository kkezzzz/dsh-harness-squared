/**
 * Cost control for PPC runs.
 *
 * Every probe is a real agent execution, so an unbounded optimizer is an
 * unbounded bill. Three ceilings apply and all three are checked *before*
 * spending: candidate count, recursion rounds, and an estimated-token budget
 * derived from the traces the run has already read. When the budget is gone the
 * run stops and records why - it never silently returns a partial result that
 * looks complete.
 */

import type { SessionEvent } from '../dsh.js'

/** Rough characters-per-token used for estimation; deliberately pessimistic. */
const CHARS_PER_TOKEN = 3.4

export interface BudgetLimits {
  maxCandidates: number
  maxRounds: number
  tokenBudget: number
}

export interface BudgetSnapshot {
  used: number
  limit: number
  candidates: number
  maxCandidates: number
  rounds: number
  maxRounds: number
  exhausted: boolean
}

/**
 * Estimate the token weight of a trace, counting only what a model would have
 * been asked to read: assistant text, tool output and call arguments.
 */
export function estimateTraceTokens(events: SessionEvent[]): number {
  let chars = 0
  for (const event of events) {
    const data = event.data as Record<string, unknown> | undefined
    if (event.type === 'assistant/message' || event.type === 'tool/result') {
      const message = data?.message as { content?: unknown } | undefined
      if (Array.isArray(message?.content)) {
        for (const block of message.content as Array<{ text?: unknown; arguments?: unknown }>) {
          if (typeof block.text === 'string') chars += block.text.length
          if (block.arguments !== undefined) {
            try {
              chars += JSON.stringify(block.arguments).length
            } catch {
              chars += 64
            }
          }
        }
      }
    }
  }
  return Math.ceil(chars / CHARS_PER_TOKEN)
}

export class Budget {
  private readonly limits: BudgetLimits
  private spent = 0
  private candidates = 0
  private rounds = 0
  private stopped = false

  constructor(limits: BudgetLimits) {
    this.limits = limits
  }

  /** Whether one more probe may run. Rounds gate {@link canRound}, not this. */
  canProbe(): boolean {
    if (this.stopped) return false
    if (this.candidates >= this.limits.maxCandidates) return false
    return this.spent < this.limits.tokenBudget
  }

  /** Whether one more round may start. */
  canRound(): boolean {
    return !this.stopped && this.rounds < this.limits.maxRounds && this.spent < this.limits.tokenBudget
  }

  /** Charge an estimate before the spend happens. */
  charge(tokens: number): void {
    this.spent += Math.max(0, Math.ceil(tokens))
    if (this.spent >= this.limits.tokenBudget) this.stopped = true
  }

  /** Record that one probe was admitted. */
  countProbe(): void {
    this.candidates += 1
    if (this.candidates >= this.limits.maxCandidates) this.stopped = true
  }

  /** Record that one round was admitted. */
  countRound(): void {
    this.rounds += 1
  }

  /** Freeze the budget, e.g. after an unsafe verdict. */
  stop(): void {
    this.stopped = true
  }

  /** Why the run stopped, for the run record. */
  get reason(): 'budget' | 'ok' {
    return this.spent >= this.limits.tokenBudget ? 'budget' : 'ok'
  }

  snapshot(): BudgetSnapshot {
    return {
      used: this.spent,
      limit: this.limits.tokenBudget,
      candidates: this.candidates,
      maxCandidates: this.limits.maxCandidates,
      rounds: this.rounds,
      maxRounds: this.limits.maxRounds,
      exhausted: !this.canProbe()
    }
  }
}
