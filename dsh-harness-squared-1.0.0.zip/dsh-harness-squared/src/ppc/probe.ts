/**
 * Probe: run one candidate shell against the same task in an isolated child.
 *
 * Isolation is the whole point, so the mechanism is worth stating precisely:
 *
 * - **Prompt isolation.** A candidate's edits are registered on the *probe
 *   agent's* context (`setup(agentCtx)`), which Cordis scopes to that agent.
 *   The parent session, its prompt and every other agent never see them.
 * - **Filesystem isolation.** By default the probe gets a fresh session whose
 *   `meta.cwd` points at a throwaway directory under the run root, so any file
 *   the probe writes lands there and disappears with it. `fork` mode reuses the
 *   parent's cwd and therefore gives up that protection; the config documents
 *   the trade-off instead of pretending otherwise.
 * - **Teardown.** The handle is disposed, the sandbox directory removed, and the
 *   child session dropped even when the probe throws or times out.
 */

import { mkdir, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'

import { analyzeFrom } from '../trace/analyze.js'
import { sanitize } from '../util/redact.js'
import { service } from '../util/services.js'
import type { HarnessSquaredConfig } from '../config.js'
import type { AgentsService, DshContext, DshSession, SessionsService, SessionEvent } from '../dsh.js'
import type { Candidate, TraceSummary } from '../types.js'

/** Services a probe needs; both are optional so a thin composition degrades. */
export interface ProbeHost {
  ctx: DshContext
  config: HarnessSquaredConfig
  /** Root for sandbox directories; usually `<root>/sandboxes`. */
  sandboxRoot: string
}

export interface ProbeRequest {
  candidate: Candidate
  /** The task text the baseline ran with, already sanitized by the caller. */
  task: string
  /** Session the baseline came from; required for fork mode. */
  baselineSessionId: string
  /** Baseline window length, used to skip inherited history in fork mode. */
  baselineEventCount: number
}

export interface ProbeOutcome {
  candidateId: string
  ok: boolean
  /** Present when `ok` is false; a stable machine-readable reason. */
  reason?: string
  detail?: string
  trace?: TraceSummary
  /** The route the probe agent was created with; asserted by cost-routing tests. */
  route: { provider: string; model: string }
  /** Session id of the child, for the run record. */
  sessionId?: string
  sandbox?: string
}

/**
 * The handle shape a probe needs. `cancel` is optional because it is an
 * implementation detail of the loop driver, not part of the published handle.
 */
interface ProbeHandle {
  agent: {
    followup(input: { content: Array<{ type: 'text'; text: string }>; source: { kind: string } }): unknown
    whenIdle(): Promise<void>
    cancel?(cause?: unknown): void
  }
  dispose(): Promise<void>
}

/** Timeout wrapper that never leaks the timer. */async function withTimeout<T>(work: Promise<T>, ms: number, onTimeout: () => void): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      onTimeout()
      reject(new Error(`probe timed out after ${ms}ms`))
    }, ms)
  })
  try {
    return await Promise.race([work, timeout])
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

/**
 * Execute one probe.
 *
 * @param host - services, config and sandbox root.
 * @param request - candidate, task and baseline identity.
 * @returns the outcome; never throws, so one bad candidate cannot end a run.
 */
export async function runProbe(host: ProbeHost, request: ProbeRequest): Promise<ProbeOutcome> {
  const { ctx, config } = host
  const sessions = service<SessionsService>(ctx, 'sessions')
  const agents = service<AgentsService>(ctx, 'agents')
  const route = { provider: config.ppc.probeModel.provider, model: config.ppc.probeModel.model }
  const base: ProbeOutcome = { candidateId: request.candidate.id, ok: false, route }

  if (!sessions || !agents) {
    return { ...base, reason: 'host-missing-services', detail: 'sessions/agents are not mounted in this composition' }
  }

  const sandbox = config.ppc.isolateWorkspace
    ? join(host.sandboxRoot, `${request.candidate.id}-${randomUUID().slice(0, 8)}`)
    : undefined

  let session: DshSession | undefined
  let handle: ProbeHandle | undefined

  try {
    if (sandbox) {
      await mkdir(sandbox, { recursive: true })
      session = sessions.create(undefined, { meta: { cwd: sandbox } })
    } else {
      session = sessions.fork(request.baselineSessionId)
    }

    const seedEvents: SessionEvent[] = session.snapshotEvents()
    const fromSeq = config.ppc.isolateWorkspace ? 0 : request.baselineEventCount

    const created = await agents.create({
      sessionId: session.id,
      agentOptions: {
        provider: route.provider,
        model: route.model,
        ...(config.ppc.probeModel.reasoningEffort ? { reasoningEffort: config.ppc.probeModel.reasoningEffort } : {})
      },
      setup: (agentCtx) => {
        applyCandidate(agentCtx, request.candidate)
      }
    })
    handle = created as unknown as ProbeHandle

    handle.agent.followup({
      content: [{ type: 'text', text: probePrompt(request.task) }],
      source: { kind: 'harness-squared' }
    })

    await withTimeout(handle.agent.whenIdle(), config.ppc.probeTimeoutMs, () => {
      try {
        handle?.agent.cancel?.('harness-squared probe timeout')
      } catch {
        /* cancellation is best effort; disposal below is the real guarantee */
      }
    })

    const events = session.snapshotEvents()
    const trace = analyzeFrom(session.id, events, fromSeq)
    return { ...base, ok: true, trace, sessionId: session.id, ...(sandbox ? { sandbox } : {}) }
  } catch (error) {
    return {
      ...base,
      reason: 'probe-failed',
      detail: error instanceof Error ? error.message : String(error),
      ...(session ? { sessionId: session.id } : {})
    }
  } finally {
    if (handle) {
      try {
        await handle.dispose()
      } catch {
        /* a failed dispose must not mask the probe result */
      }
    }
    if (sandbox) {
      try {
        await rm(sandbox, { recursive: true, force: true })
      } catch {
        /* the run root is prunable next time */
      }
    }
  }
}

/**
 * Register a candidate's sections on the probe agent's own context.
 *
 * A missing `systemPrompt` service is tolerated: the probe still runs, it just
 * runs without the candidate, and composition will see a neutral delta.
 */
export function applyCandidate(agentCtx: DshContext, candidate: Candidate): void {
  const prompt = agentCtx.systemPrompt
  if (!prompt) return
  for (const edit of candidate.edits) {
    if (edit.op !== 'append-prompt-section') continue
    try {
      prompt.section({ name: edit.name, order: edit.order, text: edit.text, interpolate: false })
    } catch {
      /* a duplicate name in this scope must not abort the probe */
    }
  }
}

/**
 * The prompt a probe receives.
 *
 * It is the original task, fenced and marked as recorded data, plus a fixed
 * closing line. It never mentions the candidate: the probe must experience the
 * change as part of its shell, not as an instruction to perform better.
 */
function probePrompt(task: string): string {
  const body = sanitize(task, 4000)
  return [
    'Repeat the task below in this workspace.',
    '',
    '<task source="previous-turn">',
    body,
    '</task>',
    '',
    'Work as you normally would. Finish with a short report of what you produced.'
  ].join('\n')
}
