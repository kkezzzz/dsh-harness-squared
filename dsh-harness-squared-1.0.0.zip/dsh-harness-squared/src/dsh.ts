/**
 * The slice of the Cordis / DeepSeek Harness host surface this plugin depends on.
 *
 * Every signature here was read out of the shipped runtime rather than guessed:
 *
 * - `cordis/src/events.ts` - `on()` registers a listener owned by the calling
 *   fiber; a `waterfall` listener receives the dispatch arguments plus a final
 *   `next()` and must call it to continue the chain.
 * - `dsh-system-prompt/lib/index.js` - `assemble()` runs
 *   `ctx.waterfall(target, 'system-prompt/assemble', assembly, context, inner)`,
 *   so a listener sees `(assembly, context, next)`.
 * - `dsh-agent-loop/lib/index.js` - `agent/pre-step` is dispatched as
 *   `waterfall('agent/pre-step', step, inner)` with
 *   `step = { messages, agent?, turn?, step?, signal, modelSelection }`.
 * - `dsh-session/lib/index.js` - `create(id?, options?)`, `fork(source, boundary?, childId?)`,
 *   events shaped `{ type, seq, time, data }`, and `session/event` observer
 *   notifications `(sessionId, event)`.
 * - `dsh-agent/lib` - `ctx.agents.create({ sessionId, agentOptions, setup })`
 *   returns a handle whose `agent` offers `followup()`, `whenIdle()`, `session`.
 * - `dsh-tools/lib/index.js` - `register(definition)` requires
 *   `output { schema, render }`; `parameters` is plain JSON Schema.
 * - `dsh-commands/lib` - `register({ name, description, input, handler })`,
 *   handler receives `{ agent, rawInput }` and returns `{ kind, text }`.
 *
 * The declarations are deliberately narrow: they cover what is used, and any
 * service this plugin can live without is optional so a thinner composition
 * still activates instead of failing to mount.
 */

/** A Cordis effect disposer; `false` means "already removed". */
export type Disposer = () => void | boolean | Promise<void>

/** One appended session event. `data` is owned by the emitting producer. */
export interface SessionEvent {
  type: string
  seq: number
  time: number
  data?: Record<string, unknown>
}

/** The read surface of a live Session needed for behavioural analysis. */
export interface DshSession {
  id: string
  header?: { cwd?: string; isSeeded?: boolean }
  /** The whole append-only log, oldest first. */
  snapshotEvents(): SessionEvent[]
}

export interface SessionCreateOptions {
  meta?: { cwd?: string; isSeeded?: boolean }
  seed?: unknown
  inheritedEventCount?: unknown
}

export interface SessionsService {
  create(id?: string, options?: SessionCreateOptions): DshSession
  get(id: string): DshSession | undefined
  list(): DshSession[]
  fork(source: string | DshSession, boundary?: number, childSessionId?: string): DshSession
}

export interface Agentlike {
  session: DshSession
  followup(input: { content: Array<{ type: 'text'; text: string }>; source: { kind: string } }): unknown
  whenIdle(): Promise<void>
}

export interface AgentHandle {
  agent: Agentlike
  dispose(): Promise<void>
}

export interface AgentsService {
  create(options: {
    sessionId: string
    agentOptions?: { provider?: string; model?: string; reasoningEffort?: string; maxTokens?: number }
    setup?: (agentCtx: DshContext, agent: Agentlike) => void
  }): Promise<AgentHandle>
}

/** One prompt section as `dsh-system-prompt` stores it before rendering. */
export interface PromptSection {
  name: string
  order: number
  text: string | ((context: unknown) => string)
  interpolate?: boolean
}

export interface PromptContextContribution {
  name: string
  order: number
  text: string | ((context: unknown) => string)
  required?: boolean
}

export interface SystemPromptService {
  section(section: PromptSection): Disposer
  context(context: PromptContextContribution): Disposer
}

/** JSON Schema as accepted by `tools.register()`. */
export type JsonSchema = Record<string, unknown>

export interface ToolContent {
  type: 'text'
  text: string
}

export interface ToolDefinition {
  name: string
  description: string
  parameters: JsonSchema
  output: {
    schema: JsonSchema
    render(args: Record<string, unknown>, value: unknown): ToolContent[]
  }
  execute(args: any, exec: any): Promise<unknown>
  timeoutMs?: number
}

export interface ToolsService {
  register(definition: ToolDefinition, options?: { when?: (context: unknown) => boolean }): Disposer
}

export interface CommandResult {
  kind: 'success' | 'error'
  text: string
}

export interface CommandsService {
  register(definition: {
    name: string
    description: string
    input?: { hint?: string }
    recordInput?: boolean
    handler: (input: { agent: Agentlike | undefined; rawInput: string }) => CommandResult | Promise<CommandResult>
  }): Disposer
}

/** The Cordis context as this plugin uses it. */
export interface DshContext {
  logger: {
    debug(...args: unknown[]): void
    info(...args: unknown[]): void
    warn(...args: unknown[]): void
    error(...args: unknown[]): void
  }
  effect(execute: () => Disposer | void, label?: string): Disposer
  on(name: string, listener: (...args: any[]) => any, options?: boolean | { prepend?: boolean }): Disposer
  get(name: string): unknown
  tools?: ToolsService
  commands?: CommandsService
  sessions?: SessionsService
  agents?: AgentsService
  systemPrompt?: SystemPromptService
}

/** The message list shape `agent/pre-step` hands a listener. */
export interface StepMessage {
  id?: string
  role?: string
  content?: Array<{ type: string; text?: string; name?: string; arguments?: unknown }> | string
}

export interface PreStepPayload {
  messages: StepMessage[]
  agent?: Agentlike
  turn?: number
  step?: number
  signal?: AbortSignal
}
