/**
 * A fake host for the offline suite.
 *
 * It implements the same surface the plugin consumes from Cordis - `effect`,
 * `on`, `get`, `systemPrompt.section`, `tools.register`, `commands.register`,
 * `sessions`, `agents` - with the semantics the real services have:
 *
 *   - `effect` disposers run in reverse order on teardown, which is how the
 *     uninstall-independence test proves the library outlives the plugin;
 *   - a scoped `systemPrompt` records sections per scope, so a test can assert
 *     that a candidate's text reached the probe and no one else;
 *   - `agents.create` receives `setup`, calls it before returning, and resolves
 *     `whenIdle()` only after the scripted trace has been written into the
 *     session - the same ordering the real loop guarantees.
 */

import { mkdtempSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

/** One session event. */
export const ev = (seq, type, data, time = 1_700_000_000_000 + seq * 10) => ({ type, seq, time, data })

export const text = (value) => ({ type: 'text', text: value })
export const call = (id, name, args = {}) => ({ type: 'tool-call', id, name, arguments: args })

export const assistant = (seq, blocks) => ev(seq, 'assistant/message', { message: { role: 'assistant', content: blocks } })
export const toolResult = (seq, callId, value, isError = false) =>
  ev(seq, 'tool/result', { message: { role: 'tool', toolCallId: callId, isError, content: [text(value)] } })
export const userMessage = (seq, value) => ev(seq, 'user/message', { message: { role: 'user', content: [text(value)] } })
export const turnStart = (seq) => ev(seq, 'turn/start', {})
export const turnEnd = (seq) => ev(seq, 'turn/end', {})

/**
 * Build a trace that is "bad" in a controlled way: N errors and M repeats.
 *
 * A trace deliberately carries no user message: the caller owns the task text,
 * and a synthetic one would shadow the real task for anything that reads the
 * last user message (the engine does exactly that).
 *
 * @param base - first sequence number.
 * @param options - shape knobs.
 * @returns a complete, closed turn.
 */
export function makeTrace(base, options = {}) {
  const { steps = 3, errors = 2, repeats = 0, files = 0, outputChars = 400 } = options
  const events = [turnStart(base)]
  let seq = base + 2
  for (let step = 0; step < steps; step += 1) {
    const blocks = [text('working')]
    blocks.push(call(`c${seq}`, 'read_file', { path: `/w/f${step}.txt` }))
    if (repeats > 0 && step < repeats) blocks.push(call(`r${seq}`, 'read_file', { path: `/w/f${step}.txt` }))
    events.push(assistant(seq, blocks))
    events.push(toolResult(seq + 1, `c${seq}`, 'x'.repeat(outputChars), step < errors))
    seq += 2
  }
  for (let index = 0; index < files; index += 1) {
    events.push(assistant(seq, [call(`w${seq}`, 'write_file', { path: `/w/out${index}.txt` })]))
    events.push(toolResult(seq + 1, `w${seq}`, 'ok'))
    seq += 2
  }
  if (options.completed !== false) events.push(turnEnd(seq))
  return events
}

/**
 * Create a fake host.
 *
 * @param options.probeTrace - `(candidateIdHint, sessionId) => events` scripted
 *   probe output. Defaults to a trace that is strictly better than the baseline.
 * @param options.root - library root; a temp dir when omitted.
 */
export function createHost(options = {}) {
  const root = options.root ?? mkdtempSync(join(tmpdir(), 'harness2-'))
  mkdirSync(root, { recursive: true })

  const effects = []
  const listeners = new Map()
  const globalSections = new Map()
  const registrations = { tools: [], commands: [], sections: [] }
  const sessionStore = new Map()
  const probeCalls = []
  const logs = []

  let sessionSeq = 0
  const nextSessionId = () => `session-${++sessionSeq}`

  const makeSession = (id, events, cwd) => {
    const log = [...events]
    return {
      id,
      header: { cwd, isSeeded: false },
      snapshotEvents: () => [...log],
      _push(events2) {
        log.push(...events2)
      }
    }
  }

  const sessions = {
    create(id, opts) {
      const sessionId = id ?? nextSessionId()
      const session = makeSession(sessionId, options.seedEvents ?? [], opts?.meta?.cwd)
      sessionStore.set(sessionId, session)
      return session
    },
    fork(source, _boundary, childId) {
      const parent = sessionStore.get(source)
      const sessionId = childId ?? nextSessionId()
      const session = makeSession(sessionId, parent ? parent.snapshotEvents() : [], parent?.header?.cwd)
      sessionStore.set(sessionId, session)
      return session
    },
    get(id) {
      return sessionStore.get(id)
    },
    list() {
      return [...sessionStore.values()]
    }
  }

  const agents = {
    async create(request) {
      const session = sessionStore.get(request.sessionId)
      const scoped = createScopedCtx()
      if (typeof request.setup === 'function') request.setup(scoped.ctx, { session })
      const candidateHint = request.agentOptions?.model ?? 'unknown'
      probeCalls.push({
        sessionId: request.sessionId,
        route: request.agentOptions ?? {},
        sections: [...scoped.sections.entries()].map(([name, section]) => ({ name, ...section })),
        cwd: session?.header?.cwd
      })

      const script = options.probeTrace ?? ((hint, sessionId) => makeTrace(1000, { errors: 0, repeats: 0, files: 2, outputChars: 120 }))
      let disposed = false
      const handle = {
        agent: {
          session,
          followup() {
            return undefined
          },
          async whenIdle() {
            const produced = script(candidateHint, request.sessionId)
            if (session) session._push(produced)
          },
          cancel() {
            return undefined
          }
        },
        async dispose() {
          disposed = true
          scoped.dispose()
        }
      }
      Object.defineProperty(handle, 'disposed', { get: () => disposed })
      return handle
    }
  }

  function createScopedCtx() {
    const sections = new Map()
    const disposers = []
    const ctx = {
      logger,
      effect: (fn) => {
        const disposer = fn()
        if (typeof disposer === 'function') disposers.push(disposer)
        return disposer ?? (() => undefined)
      },
      on: () => () => undefined,
      get: () => undefined,
      systemPrompt: {
        section(section) {
          sections.set(section.name, section)
          return () => sections.delete(section.name)
        },
        context: () => () => undefined
      }
    }
    return {
      ctx,
      sections,
      dispose() {
        for (const disposer of disposers.reverse()) {
          try {
            disposer()
          } catch {
            /* ignore */
          }
        }
      }
    }
  }

  const logger = {
    debug: () => undefined,
    info: (...args) => logs.push(['info', args.map(String).join(' ')]),
    warn: (...args) => logs.push(['warn', args.map(String).join(' ')]),
    error: (...args) => logs.push(['error', args.map(String).join(' ')])
  }

  const ctx = {
    logger,
    effect(fn, label) {
      const disposer = fn()
      const entry = { disposer: typeof disposer === 'function' ? disposer : () => undefined, label }
      effects.push(entry)
      return () => {
        try {
          entry.disposer()
        } catch {
          /* ignore */
        }
      }
    },
    on(name, listener) {
      const list = listeners.get(name) ?? []
      list.push(listener)
      listeners.set(name, list)
      return () => {
        const index = list.indexOf(listener)
        if (index >= 0) list.splice(index, 1)
        return index >= 0
      }
    },
    get(name) {
      if (name === 'sessions') return sessions
      if (name === 'agents') return agents
      if (name === 'commands') return ctx.commands
      if (name === 'tools') return ctx.tools
      return undefined
    },
    sessions,
    agents,
    systemPrompt: {
      section(section) {
        globalSections.set(section.name, section)
        registrations.sections.push(section.name)
        return () => globalSections.delete(section.name)
      },
      context: () => () => undefined
    },
    tools: {
      register(definition) {
        registrations.tools.push(definition)
        return () => undefined
      }
    },
    commands: {
      register(definition) {
        registrations.commands.push(definition)
        return () => undefined
      }
    }
  }

  return {
    ctx,
    root,
    registrations,
    globalSections,
    probeCalls,
    logs,
    sessions,
    agents,
    /** Fire every listener registered for one event, waterfall-style. */
    async emit(name, ...args) {
      const list = listeners.get(name) ?? []
      let index = 0
      const next = async () => {
        const listener = list[index]
        index += 1
        if (!listener) return args[0]
        return listener(...args, next)
      }
      return next()
    },
    /** Run every `ctx.effect` disposer in reverse order, as fiber teardown does. */
    dispose() {
      for (const entry of [...effects].reverse()) {
        try {
          entry.disposer()
        } catch {
          /* ignore */
        }
      }
    },
    listenerCount: (name) => (listeners.get(name) ?? []).length
  }
}
